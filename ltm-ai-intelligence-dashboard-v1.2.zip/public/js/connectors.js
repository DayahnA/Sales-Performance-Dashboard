/* ================================================================
   MICROSOFT CONNECTORS
   Entra ID (MSAL) · Graph · SharePoint · Dataverse · Copilot Studio
   agent (Direct Line) · Power Automate
   Every connector has a test*() function used by ⚙️ Data settings.
   Test functions accept a DRAFT settings object, so users can test
   before saving. Each returns { ok, msg, detail? } and never throws.
   ================================================================ */
(function () {
  const { ENTRA, GRAPH, SETTINGS, spInfo, dvInfo, agentInfo, paInfo } = window.SPD;
  const DVCOLS = () => window.SPD.DATAVERSE.columns.performance;
  let msalInstance = null, account = null;

  // ─────────────────────────────────────────────
  // 🔐 ENTRA ID — MSAL.js (Auth Code + PKCE, no secret)
  // ─────────────────────────────────────────────
  async function initAuth() {
    if (!ENTRA.isConfigured) return null;
    if (!ENTRA.canRun) { console.info('ℹ️ Sign-in needs http(s) — opened as a file, demo mode.'); return null; }
    if (!window.msal) throw new Error('Microsoft sign-in library did not load');
    msalInstance = new msal.PublicClientApplication({
      auth: { clientId: ENTRA.clientId, authority: `https://login.microsoftonline.com/${ENTRA.tenantId}`,
        redirectUri: ENTRA.redirectUri, postLogoutRedirectUri: ENTRA.redirectUri },
      cache: { cacheLocation: 'sessionStorage', storeAuthStateInCookie: false }
    });
    await msalInstance.initialize();
    const result = await msalInstance.handleRedirectPromise();
    account = result?.account || msalInstance.getAllAccounts()[0] || null;
    if (account) msalInstance.setActiveAccount(account);
    return account;
  }
  function signIn() {
    if (!ENTRA.canRun) { window.UI?.toast('🔐 Sign-in works once the dashboard is opened from Netlify or http://localhost'); return; }
    if (!msalInstance) { window.UI?.toast('⚙️ Microsoft sign-in is not ready — check your connection'); return; }
    msalInstance.loginRedirect({ scopes: ENTRA.loginScopes, prompt: 'select_account' });
  }
  function signOut() { if (msalInstance) msalInstance.logoutRedirect({ account }); }
  async function getMicrosoftToken(scopes) {
    if (!msalInstance || !account) throw new Error(ENTRA.canRun ? 'Sign in with Microsoft first.' : 'Microsoft sign-in only works when the dashboard is opened from Netlify or http://localhost (not as a local file).');
    try { return (await msalInstance.acquireTokenSilent({ scopes, account })).accessToken; }
    catch (e) {
      if (e instanceof msal.InteractionRequiredAuthError) { await msalInstance.acquireTokenRedirect({ scopes, account }); }
      throw new Error(`Could not get a token for ${scopes[0]} (${e.errorCode || e.message}). An admin may need to grant consent.`);
    }
  }
  const isSignedIn = () => !!account;
  const getAccount = () => account;
  const ok = (msg, detail) => ({ ok: true, msg, detail });
  const fail = (e) => ({ ok: false, msg: e?.message || String(e) });
  const netErr = (e, what) => e instanceof TypeError ? new Error(`${what} could not be reached — the browser blocked the request (CORS / network) or the URL is wrong.`) : e;

  // ─────────────────────────────────────────────
  // 📊 GRAPH helpers
  // ─────────────────────────────────────────────
  async function graphFetch(path, opts = {}) {
    const token = await getMicrosoftToken(GRAPH.scopes);
    let res;
    try { res = await fetch(path.startsWith('http') ? path : `${GRAPH.baseUrl}${path}`, { ...opts, headers: { Authorization: `Bearer ${token}`, ...(opts.headers || {}) } }); }
    catch (e) { throw netErr(e, 'Microsoft Graph'); }
    if (!res.ok) {
      let m = ''; try { m = (await res.json()).error?.message || ''; } catch {}
      const hint = res.status === 404 ? ' (not found — check the site URL / file path)' : res.status === 403 ? ' (no access — check your SharePoint permissions)' : '';
      throw new Error(`SharePoint ${res.status}${hint}${m ? ': ' + m : ''}`);
    }
    return res.status === 204 ? null : res.json();
  }
  const siteCache = {};
  async function getSiteId(sp = spInfo()) {
    const key = sp.hostname + sp.sitePath;
    if (!siteCache[key]) siteCache[key] = (await graphFetch(`/sites/${sp.hostname}:${sp.sitePath}?$select=id,displayName`));
    return siteCache[key].id;
  }
  const encPath = (p) => p.split('/').map(encodeURIComponent).join('/');

  // ─────────────────────────────────────────────
  // 📁 SHAREPOINT — Excel workbook as data source
  // ─────────────────────────────────────────────
  async function loadSharePointGrid(sp = spInfo()) {
    if (!sp.hasFile) throw new Error('Choose a SharePoint site and Excel file in Data settings');
    const siteId = await getSiteId(sp);
    const wb = `/sites/${siteId}/drive/root:/${encPath(sp.filePath)}:/workbook`;
    if (sp.tableName) {
      const t = `${wb}/tables/${encodeURIComponent(sp.tableName)}`;
      const [cols, rows] = await Promise.all([graphFetch(`${t}/columns`), graphFetch(`${t}/rows`)]);
      return [cols.value.map(c => c.name), ...rows.value.map(r => r.values[0])];
    }
    let sheet = sp.worksheet;
    if (!sheet) sheet = (await graphFetch(`${wb}/worksheets?$select=name`)).value[0]?.name;
    if (!sheet) throw new Error('The workbook has no worksheets');
    return (await graphFetch(`${wb}/worksheets/${encodeURIComponent(sheet)}/usedRange(valuesOnly=true)?$select=values`)).values;
  }
  async function listSharePointFiles(folder = '', sp = spInfo()) {
    const siteId = await getSiteId(sp);
    const p = folder.replace(/^\/+|\/+$/g, '');
    const url = p ? `/sites/${siteId}/drive/root:/${encPath(p)}:/children` : `/sites/${siteId}/drive/root/children`;
    const res = await graphFetch(`${url}?$select=name,folder,file,lastModifiedDateTime,size&$top=200`);
    return res.value.filter(i => i.folder || /\.(xlsx|xlsm|xls|csv)$/i.test(i.name))
      .map(i => ({ name: i.name, isFolder: !!i.folder, path: p ? `${p}/${i.name}` : i.name, modified: i.lastModifiedDateTime, size: i.size }));
  }
  async function listWorksheets(sp = spInfo()) {
    const siteId = await getSiteId(sp);
    return (await graphFetch(`/sites/${siteId}/drive/root:/${encPath(sp.filePath)}:/workbook/worksheets?$select=name`)).value.map(w => w.name);
  }
  async function uploadToSharePoint(file, sp = spInfo()) {
    if (!sp.isConfigured || !isSignedIn()) return { skipped: true };
    const siteId = await getSiteId(sp);
    const path = `${sp.folder}/${new Date().toISOString().replace(/[:.]/g, '-')}_${file.name.replace(/[^\w.\- ]/g, '_')}`;
    const token = await getMicrosoftToken(GRAPH.scopes);
    if (file.size < 4 * 1024 * 1024) {
      const res = await fetch(`${GRAPH.baseUrl}/sites/${siteId}/drive/root:/${encPath(path)}:/content`, { method: 'PUT', headers: { Authorization: `Bearer ${token}` }, body: file });
      if (!res.ok) throw new Error(`SharePoint upload failed: ${res.status}`);
      return res.json();
    }
    const session = await graphFetch(`/sites/${siteId}/drive/root:/${encPath(path)}:/createUploadSession`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ item: { '@microsoft.graph.conflictBehavior': 'rename' } }) });
    const chunk = 5 * 320 * 1024; let start = 0, last;
    while (start < file.size) {
      const end = Math.min(start + chunk, file.size);
      last = await fetch(session.uploadUrl, { method: 'PUT', headers: { 'Content-Range': `bytes ${start}-${end - 1}/${file.size}` }, body: file.slice(start, end) });
      if (!last.ok && last.status !== 202) throw new Error(`Chunk upload failed: ${last.status}`);
      start = end;
    }
    return last.json();
  }

  /** TEST SharePoint: site → (file → rows) → archive folder */
  async function testSharePoint(draft, { requireFile = false } = {}) {
    try {
      const sp = spInfo(draft);
      if (!sp.isConfigured) throw new Error('Enter a site URL like https://tenant.sharepoint.com/sites/SiteName');
      if (requireFile && !sp.hasFile) throw new Error('Choose the Excel file that holds the sales data');
      delete siteCache[sp.hostname + sp.sitePath];
      await getSiteId(sp);
      const site = siteCache[sp.hostname + sp.sitePath];
      const steps = [`Site "${site.displayName || sp.sitePath}" found`];
      if (sp.hasFile) {
        const grid = await loadSharePointGrid(sp);
        const { records, errors } = window.Upload.gridToRecords(grid);
        if (!records.length) throw new Error(`Opened ${sp.filePath}, but no sales rows were recognised${errors[0] ? ' — ' + errors[0] : ''}`);
        steps.push(`${records.length} sales rows read from ${sp.filePath.split('/').pop()}`);
      }
      if (draft.archiveUploadsToSharePoint) {
        try { await graphFetch(`/sites/${await getSiteId(sp)}/drive/root:/${encPath(sp.folder)}?$select=id`); steps.push(`archive folder "${sp.folder}" found`); }
        catch { steps.push(`⚠ archive folder "${sp.folder}" not found — it will be created on first upload`); }
      }
      return ok(steps.join(' · '));
    } catch (e) { return fail(e); }
  }

  // ─────────────────────────────────────────────
  // 🗄️ DATAVERSE — Web API (OData)
  // ─────────────────────────────────────────────
  async function dvFetch(path, opts = {}, dv = dvInfo()) {
    if (!dv.isConfigured) throw new Error('Enter your Dataverse environment URL (https://yourorg.crm4.dynamics.com)');
    const token = await getMicrosoftToken(dv.scopes);
    let res;
    try {
      res = await fetch(`${dv.url}/api/data/${dv.apiVersion}/${path}`, { ...opts, headers: {
        Authorization: `Bearer ${token}`, Accept: 'application/json', 'Content-Type': 'application/json; charset=utf-8',
        'OData-MaxVersion': '4.0', 'OData-Version': '4.0', Prefer: 'odata.include-annotations="*"', ...(opts.headers || {}) } });
    } catch (e) { throw netErr(e, 'Dataverse'); }
    if (!res.ok) {
      let m = ''; try { m = (await res.json()).error?.message || ''; } catch {}
      const hint = res.status === 404 ? ' (table not found — check the entity set name)' : res.status === 403 ? ' (no security role on this table)' : res.status === 401 ? ' (not authorised — check consent / environment URL)' : '';
      throw new Error(`Dataverse ${res.status}${hint}${m ? ': ' + m : ''}`);
    }
    return res.status === 204 ? null : res.json();
  }
  async function dvGetAll(entitySet, query = '', dv = dvInfo()) {
    let url = `${entitySet}${query ? '?' + query : ''}`; const out = [];
    while (url) {
      const page = await dvFetch(url, {}, dv); out.push(...page.value);
      const next = page['@odata.nextLink'];
      url = next ? next.split(`/api/data/${dv.apiVersion}/`)[1] : null;
    }
    return out;
  }
  function mapDvRow(r) {
    const c = DVCOLS();
    return { id: r[c.id], account: r[c.account], area: r[c.area] || 'Unassigned', geo: r[c.geo] || 'South Africa',
      accountType: r[c.accountType] || 'Existing', leader: r[c.leader] || 'Unassigned', fiscalYear: r[c.fiscalYear], quarter: r[c.quarter],
      target: Number(r[c.target]) || 0, be: Number(r[c.be]) || 0, lost: !!r[c.lost], marginTarget: r[c.marginTarget], actualMargin: r[c.actualMargin] };
  }
  async function loadDataverseRecords() {
    return (await dvGetAll(dvInfo().entitySets.performance, '$filter=statecode eq 0')).map(mapDvRow);
  }

  /** TEST Dataverse: WhoAmI → table read → required columns → optional tables */
  async function testDataverse(draft) {
    try {
      const dv = dvInfo(draft);
      if (!dv.isConfigured) throw new Error('Enter a URL like https://yourorg.crm4.dynamics.com');
      const who = await dvFetch('WhoAmI()', {}, dv);
      const steps = [`Environment reached (user ${String(who.UserId).slice(0, 8)}…)`];
      const page = await dvFetch(`${dv.entitySets.performance}?$top=1&$count=true`, { headers: { Prefer: 'odata.maxpagesize=1' } }, dv);
      const count = page['@odata.count'];
      steps.push(`table ${dv.entitySets.performance} readable${count !== undefined ? ` (${count}${count >= 5000 ? '+' : ''} rows)` : ''}`);
      if (page.value[0]) {
        const c = DVCOLS(), missing = ['account', 'quarter', 'target', 'be'].filter(k => !(c[k] in page.value[0]));
        if (missing.length) throw new Error(`Table found, but columns are missing: ${missing.map(k => c[k]).join(', ')} (see docs/DATAVERSE_SCHEMA.md)`);
      } else steps.push('⚠ table is empty — upload data to fill it');
      for (const t of ['statusRules', 'commitments']) {
        try { await dvFetch(`${dv.entitySets[t]}?$top=1&$select=createdon`, {}, dv); } catch { steps.push(`⚠ optional table ${dv.entitySets[t]} not found`); }
      }
      return ok(steps.join(' · '));
    } catch (e) { return fail(e); }
  }

  async function saveRecordsToDataverse(records, batchName) {
    const dv = dvInfo();
    if (!dv.isConfigured || !isSignedIn()) return { skipped: true };
    const c = DVCOLS(); let created = 0;
    for (const r of records) {
      await dvFetch(dv.entitySets.performance, { method: 'POST', body: JSON.stringify({
        [c.account]: r.account, [c.area]: r.area, [c.geo]: r.geo, [c.accountType]: r.accountType, [c.leader]: r.leader,
        [c.fiscalYear]: r.fiscalYear, [c.quarter]: r.quarter, [c.target]: r.target, [c.be]: r.be, [c.lost]: !!r.lost,
        [c.marginTarget]: r.marginTarget ?? null, [c.actualMargin]: r.actualMargin ?? null }) });
      created++;
    }
    await dvFetch(dv.entitySets.importBatch, { method: 'POST',
      body: JSON.stringify({ cr_name: batchName, cr_rowcount: created, cr_importedby: account?.username || '' }) }).catch(e => console.warn(e));
    return { created };
  }
  async function loadStatusRulesFromDataverse() {
    const dv = dvInfo(); if (!dv.isConfigured || !isSignedIn()) return null;
    const rows = await dvGetAll(dv.entitySets.statusRules, '$select=cr_rulesjson&$top=1&$orderby=modifiedon desc');
    return rows[0]?.cr_rulesjson ? JSON.parse(rows[0].cr_rulesjson) : null;
  }
  async function saveStatusRulesToDataverse(rules) {
    const dv = dvInfo(); if (!dv.isConfigured || !isSignedIn()) return { skipped: true };
    return dvFetch(dv.entitySets.statusRules, { method: 'POST', body: JSON.stringify({ cr_name: `Rules ${new Date().toISOString()}`, cr_rulesjson: JSON.stringify(rules) }) });
  }
  async function saveCommitmentToDataverse(c) {
    const dv = dvInfo(); if (!dv.isConfigured || !isSignedIn()) return { skipped: true };
    return dvFetch(dv.entitySets.commitments, { method: 'POST',
      body: JSON.stringify({ cr_name: c.account, cr_leader: c.leader, cr_amount: c.amount, cr_weekending: c.week, cr_note: c.note }) });
  }

  // ─────────────────────────────────────────────
  // 🤖 COPILOT STUDIO AGENT — Direct Line connection
  // mode 'endpoint': Copilot Studio token endpoint (agents with "No authentication"
  //                  or "Authenticate manually"); regional Direct Line URL auto-detected
  // mode 'server'  : Netlify Function /api/agent-token using DIRECTLINE_SECRET
  // ─────────────────────────────────────────────
  async function getAgentConnection(s = SETTINGS) {
    const a = agentInfo(s);
    if (!a.enabled) throw new Error('The agent connection is turned off');
    if (a.mode === 'endpoint') {
      if (!/^https:\/\//i.test(a.tokenEndpoint)) throw new Error('Paste the token endpoint from Copilot Studio → Channels → Mobile app (or Web app)');
      let res;
      try { res = await fetch(a.tokenEndpoint, { method: 'GET' }); } catch (e) { throw netErr(e, 'The token endpoint'); }
      if (!res.ok) throw new Error(`Token endpoint returned ${res.status}${res.status === 404 ? ' — check the URL and that the agent is published' : ''}`);
      const data = await res.json();
      if (!data.token) throw new Error('The token endpoint did not return a token');
      let domain = 'https://directline.botframework.com/v3/directline';
      try {
        const u = new URL(a.tokenEndpoint);
        const rs = await fetch(`${u.origin}/powervirtualagents/regionalchannelsettings?api-version=2022-03-01-preview`);
        if (rs.ok) { const j = await rs.json(); const dl = j?.channelUrlsById?.directline; if (dl) domain = `${dl.replace(/\/$/, '')}/v3/directline`; }
      } catch { /* fall back to the global Direct Line domain */ }
      const u = getAccount();
      return { token: data.token, domain, userId: u ? `dl_${u.localAccountId || u.homeAccountId}`.slice(0, 64) : undefined, userName: u?.name };
    }
    // server mode
    const userToken = isSignedIn() ? await getMicrosoftToken(['User.Read']) : '';
    let res;
    try { res = await fetch(a.serverEndpoint, { method: 'POST', headers: { Authorization: `Bearer ${userToken}` } }); }
    catch (e) { throw netErr(e, 'The Netlify agent function'); }
    if (res.status === 404) throw new Error('/api/agent-token not found — deploy to Netlify (or run `netlify dev`) to use server mode');
    let body = {}; try { body = await res.json(); } catch {}
    if (!res.ok) throw new Error(body.error || `Agent token function returned ${res.status}`);
    return body;
  }

  /** TEST agent: get token → open a Direct Line conversation */
  async function testAgent(draft) {
    try {
      const c = await getAgentConnection(draft);
      let res;
      try { res = await fetch(`${c.domain}/conversations`, { method: 'POST', headers: { Authorization: `Bearer ${c.token}` } }); }
      catch (e) { throw netErr(e, 'Direct Line'); }
      if (!res.ok) throw new Error(`Token received, but Direct Line refused the conversation (${res.status}). Check the agent is published and the region is correct.`);
      const conv = await res.json();
      const region = new URL(c.domain).hostname.split('.')[0];
      return ok(`Token received · conversation ${String(conv.conversationId).slice(0, 8)}… opened · region ${region === 'directline' ? 'global' : region}`);
    } catch (e) { return fail(e); }
  }

  // ─────────────────────────────────────────────
  // 📨 POWER AUTOMATE
  // mode 'url'   : flow "When an HTTP request is received" URL entered in Data settings
  //                auth 'none'  → anyone with the URL (SAS signature in the URL)
  //                auth 'entra' → tenant-only trigger, OAuth token (audience service.flow.microsoft.com)
  // mode 'server': Netlify relay /api/power-automate (POWER_AUTOMATE_URL env var)
  // ─────────────────────────────────────────────
  async function postToFlow(payload, s = SETTINGS) {
    const p = paInfo(s);
    if (!p.enabled) throw new Error('The Power Automate connection is turned off');
    let url, headers = { 'Content-Type': 'application/json' };
    if (p.mode === 'server') {
      url = p.relayEndpoint;
      if (isSignedIn()) headers.Authorization = `Bearer ${await getMicrosoftToken(['User.Read'])}`;
    } else {
      if (!/^https:\/\//i.test(p.url)) throw new Error('Paste the flow\'s HTTP POST URL');
      url = p.url;
      if (p.auth === 'entra') headers.Authorization = `Bearer ${await getMicrosoftToken(p.flowScopes)}`;
    }
    let res;
    try { res = await fetch(url, { method: 'POST', headers, body: JSON.stringify(payload) }); }
    catch (e) { throw netErr(e, p.mode === 'server' ? 'The Netlify relay' : 'The flow URL'); }
    if (res.ok || res.status === 202) return res;
    let m = ''; try { const j = await res.json(); m = j.error?.message || j.error || ''; } catch {}
    const hint = res.status === 401 || res.status === 403 ? (p.mode === 'url' && p.auth === 'none' ? ' — this flow only allows tenant users: set Authentication to "Entra ID"' : ' — not authorised')
      : res.status === 404 ? (p.mode === 'server' ? ' — deploy to Netlify to use the relay' : ' — the flow URL is wrong or the flow is off') : '';
    throw new Error(`Flow returned ${res.status}${hint}${m ? ': ' + m : ''}`);
  }
  function basePayload(action, data = {}) {
    return { action, account: data.account || '', leader: data.leader || '', to: data.to || '',
      subject: data.subject || `Sales performance: ${data.account || ''}`, body: data.body || '',
      target: data.target ?? '', be: data.be ?? '', gap: data.gap ?? '', status: data.status || '', period: data.period || '',
      timestamp: new Date().toISOString(), triggeredBy: 'LTM-AI Intelligence Dashboard', user: account?.username || 'demo' };
  }
  async function sendToPowerAutomate(action, data) {
    if (!paInfo().isConfigured) { window.UI?.openSetupGuide('Power Automate', action, data?.account || data?.subject || '—'); return { skipped: true }; }
    await postToFlow(basePayload(action, data));
    return { ok: true };
  }

  /** TEST Power Automate: send a harmless "test" action and expect 200/202 */
  async function testPowerAutomate(draft) {
    try {
      const t0 = performance.now();
      const res = await postToFlow(basePayload('test', { subject: 'Connection test from LTM-AI Intelligence Dashboard' }), draft);
      const ms = Math.round(performance.now() - t0);
      return ok(`Flow accepted the test call (${res.status}) in ${ms} ms${paInfo(draft).mode === 'server' ? ' via the Netlify relay' : ''}`);
    } catch (e) { return fail(e); }
  }

  window.Connectors = {
    initAuth, signIn, signOut, getMicrosoftToken, isSignedIn, getAccount,
    loadSharePointGrid, listSharePointFiles, listWorksheets, uploadToSharePoint, testSharePoint,
    loadDataverseRecords, testDataverse, saveRecordsToDataverse, loadStatusRulesFromDataverse, saveStatusRulesToDataverse, saveCommitmentToDataverse,
    getAgentConnection, testAgent, sendToPowerAutomate, testPowerAutomate
  };
})();
