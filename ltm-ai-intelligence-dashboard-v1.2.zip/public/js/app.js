/* ================================================================
   LTM-AI INTELLIGENCE DASHBOARD — APP
   Clock · Greeting · Data source (Excel upload | Dataverse | SharePoint)
   · Filters · KPIs · Chart · Leaders · Risk · Accounts · Commitments
   · Status rules · Upload wizard · Data settings & connection tests
   ================================================================ */
(function () {
  const { CONFIG, ENTRA, SETTINGS, DEFAULT_SETTINGS, saveSettings, spInfo, dvInfo, agentInfo, paInfo } = window.SPD;
  const D = window.Data, C = window.Connectors;
  const $ = (s, el = document) => el.querySelector(s);
  const $$ = (s, el = document) => [...el.querySelectorAll(s)];
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const SOURCE_NAMES = { excel: 'Excel upload', dataverse: 'Dataverse', sharepoint: 'SharePoint' };
  const CONN_NAMES = { dataverse: 'Dataverse', sharepoint: 'SharePoint', agent: 'Copilot agent', powerAutomate: 'Power Automate' };
  const CONNS = Object.keys(CONN_NAMES);

  const state = { records: [], rules: D.defaultRules(), commitments: [], source: 'demo', view: 'overview',
    f: { fy: CONFIG.fiscalYear, period: 'FY', leader: 'All', type: 'All', area: 'All' }, sort: { key: 'gap', dir: -1 }, search: '', selectedAccount: null };

  // ─────────────────────────────────────────────
  // ⏰ CLOCK + 👋 GREETING
  // ─────────────────────────────────────────────
  function updateClock() { $('#clockDisplay').textContent = new Date().toLocaleTimeString('en-ZA', { hour: '2-digit', minute: '2-digit', timeZone: 'Africa/Johannesburg' }) + ' SAST'; }
  function setGreeting() {
    const h = new Date().getHours(), g = h < 12 ? 'Good morning' : h < 17 ? 'Good afternoon' : 'Good evening';
    const name = C.getAccount()?.name?.split(' ')[0] || '';
    $('#greeting').textContent = `${g}${name ? ', ' + name : ''} 👋`;
    const dateStr = new Date().toLocaleDateString('en-ZA', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
    $('#dateLine').innerHTML = `${dateStr} · ${esc(state.f.fy)} · current quarter <b>${D.currentFiscalQuarter()}</b> · company target <b>${D.fmtM(CONFIG.companyTarget)}</b> · source <b>${esc(SOURCE_NAMES[SETTINGS.source])}</b>`;
  }

  // ─────────────────────────────────────────────
  // 🔌 STATUS · TOAST · MODALS
  // ─────────────────────────────────────────────
  function showDataStatus(s) {
    const map = { loading: ['⟳ Connecting…', '#cbd5e1'], dataverse: ['● Live · Dataverse', '#7ee2a8'], sharepoint: ['● Live · SharePoint', '#7ee2a8'],
      saved: ['● Excel upload', '#93c5fd'], demo: ['◌ Demo data', '#fcd34d'] };
    const [t, c] = map[s] || map.demo, b = $('#dataStatusBadge'); b.textContent = t; b.style.color = c;
    $('#footSource').textContent = t.replace(/^[●◌⟳]\s/, 'Source: ');
  }
  function sourceError(msg) {
    const b = $('#sourceError');
    b.innerHTML = `⚠️ <b>${esc(SOURCE_NAMES[SETTINGS.source])}:</b> ${esc(msg)} Showing ${state.source === 'saved' ? 'your last upload' : 'demo data'} instead. <a href="#" id="seOpen" style="color:inherit;font-weight:700">Open Data settings →</a>`;
    b.classList.remove('hidden');
    $('#seOpen').onclick = e => { e.preventDefault(); openSettings(SETTINGS.source); };
  }
  function toast(msg) { const t = $('#toastNotif'); t.textContent = msg; t.classList.add('toast-show'); clearTimeout(toast._t); toast._t = setTimeout(() => t.classList.remove('toast-show'), 4500); }
  function openModal(id) { $('#' + id)?.classList.add('open'); document.body.style.overflow = 'hidden'; }
  function closeModal(id) { $('#' + id)?.classList.remove('open'); if (!$$('.modal-overlay.open').length) document.body.style.overflow = ''; }
  function openSetupGuide(name, action, subject) { $('#setupName').textContent = name; $('#setupAction').textContent = action; $('#setupSubject').textContent = subject; openModal('setupModal'); }

  // ─────────────────────────────────────────────
  // 📊 LOAD DATA — from the source chosen in Data settings
  // ─────────────────────────────────────────────
  async function loadData() {
    showDataStatus('loading'); $('#sourceError').classList.add('hidden');
    const saved = D.load();
    if (saved.rules) state.rules = saved.rules;
    if (saved.commitments) state.commitments = saved.commitments;
    const fallback = () => saved.records?.length ? finish(saved.records, 'saved') : finish(D.demoRecords(), 'demo');
    const src = SETTINGS.source;
    if (src === 'dataverse') {
      try {
        if (!dvInfo().isConfigured) throw new Error('Add your Dataverse environment URL.');
        try { const r = await C.loadStatusRulesFromDataverse(); if (r?.length) state.rules = r; } catch (e) { console.warn('Rules:', e.message); }
        const dv = await C.loadDataverseRecords();
        if (!dv.length) throw new Error(`The table "${dvInfo().entitySets.performance}" has no rows yet.`);
        return finish(dv, 'dataverse');
      } catch (e) { fallback(); return sourceError(e.message); }
    }
    if (src === 'sharepoint') {
      try {
        if (!spInfo().hasFile) throw new Error('Choose a SharePoint site and Excel file.');
        const { records, errors } = window.Upload.gridToRecords(await C.loadSharePointGrid());
        if (!records.length) throw new Error(errors[0] || 'No sales rows were found in the workbook.');
        if (errors.length) toast(`⚠️ ${errors.length} row(s) in the SharePoint file could not be read`);
        return finish(records, 'sharepoint');
      } catch (e) { fallback(); return sourceError(e.message); }
    }
    fallback();
  }
  function finish(records, source) {
    state.records = records; state.source = source;
    const fys = [...new Set(records.map(r => r.fiscalYear))].sort();
    if (!fys.includes(state.f.fy)) state.f.fy = fys[fys.length - 1] || CONFIG.fiscalYear;
    showDataStatus(source); render();
  }

  // ─────────────────────────────────────────────
  // 🔎 FILTERING
  // ─────────────────────────────────────────────
  function baseRows(ignorePeriod = false, ignoreLeader = false) {
    const qs = D.quartersFor(state.f.period);
    return state.records.filter(r => r.fiscalYear === state.f.fy && (state.f.type === 'All' || r.accountType === state.f.type) &&
      (state.f.area === 'All' || r.area === state.f.area) && (ignoreLeader || state.f.leader === 'All' || r.leader === state.f.leader) &&
      (ignorePeriod || qs.includes(r.quarter)));
  }
  function accountSummaries(rows) {
    return [...D.groupBy(rows, 'account')].map(([account, rs]) => {
      const agg = D.aggregate(rs);
      return { account, rows: rs, ...agg, status: D.statusFor(agg, state.rules), leader: [...new Set(rs.map(r => r.leader))].join(' → '), area: rs[0].area, accountType: rs[0].accountType };
    });
  }

  // ─────────────────────────────────────────────
  // 🖼️ RENDER
  // ─────────────────────────────────────────────
  function render() {
    renderFilters();
    const rows = baseRows(), accts = accountSummaries(rows), total = D.aggregate(rows);
    renderKPIs(total, accts); renderBanner(); renderChart(); renderGauge(total, D.statusFor(total, state.rules), accts);
    renderLeaders(rows); renderRisk(accts); renderTop(accts); renderNN(accts); renderAccountsTable(accts, total);
    renderLeaderTable(); renderCommitments(); renderInsight(total, accts); renderNotifications(accts); setGreeting(); updateConnDots();
    window.Agent?.sendContext?.();
  }
  function opts(sel, values, cur) {
    sel.innerHTML = values.map(v => `<option ${v === cur ? 'selected' : ''} value="${esc(v)}">${esc(v === 'All' && sel.id === 'fLeader' ? `Overall (${CONFIG.overallLeader})` : v)}</option>`).join('');
  }
  function renderFilters() {
    const fyRows = state.records.filter(r => r.fiscalYear === state.f.fy);
    opts($('#fFY'), [...new Set(state.records.map(r => r.fiscalYear))].sort(), state.f.fy);
    opts($('#fLeader'), ['All', ...[...new Set(fyRows.map(r => r.leader))].sort()], state.f.leader);
    opts($('#fType'), ['All', ...[...new Set(fyRows.map(r => r.accountType))].sort()], state.f.type);
    opts($('#fArea'), ['All', ...[...new Set(fyRows.map(r => r.area))].sort()], state.f.area);
    $$('#fPeriod button').forEach(b => b.classList.toggle('on', b.dataset.p === state.f.period));
    $('#chartBadge').textContent = `${state.f.period} ${state.f.fy}`;
  }
  const kpi = (cls, label, value, sub) => `<div class="kpi ${cls}"><div class="kpi-label">${label}</div><div class="kpi-value">${value}</div><div class="kpi-sub">${sub}</div></div>`;
  function renderKPIs(t, accts) {
    const onTrack = accts.filter(a => a.status.onTrack).length, lost = accts.filter(a => a.lost).length;
    const who = state.f.leader === 'All' ? `Overall · ${CONFIG.overallLeader}` : state.f.leader;
    $('#kpis').innerHTML = kpi('', `Target · ${state.f.period}`, D.fmtM(t.target), esc(who)) +
      kpi('coral', 'Best estimate (BE)', D.fmtM(t.be), D.quartersFor(state.f.period).join(' + ')) +
      kpi(t.gap > 0 ? 'red' : 'green', 'Gap (Target − BE)', D.fmtGap(t.gap), t.gap > 0 ? 'Behind plan' : t.gap < 0 ? 'Ahead of plan' : 'On target') +
      kpi('', 'Attainment', D.fmtPct(t.attainment), 'BE ÷ Target') +
      kpi('green', 'Accounts on track', `${onTrack}<small style="font-size:.9rem;color:var(--muted);font-weight:700"> / ${accts.length}</small>`, 'Per your status rules') +
      kpi('black', 'Lost accounts', lost, lost ? 'Shown in black' : 'None lost');
    $$('#kpis .kpi').forEach(k => { k.classList.add('kpi-updated'); setTimeout(() => k.classList.remove('kpi-updated'), 600); });
  }
  function renderBanner() {
    const b = $('#targetBanner');
    if (state.f.leader !== 'All' || state.f.type !== 'All' || state.f.area !== 'All') { b.classList.add('hidden'); return; }
    const acctSum = D.aggregate(state.records.filter(r => r.fiscalYear === state.f.fy)).target, diff = acctSum - CONFIG.companyTarget;
    b.classList.remove('hidden'); b.classList.toggle('warn', Math.abs(diff) > 0.005);
    b.innerHTML = `🎯 Company target <b>${D.fmtM(CONFIG.companyTarget)}</b> (${esc(state.f.fy)}) · Sum of account targets <b>${D.fmtM(acctSum)}</b> · ` +
      (Math.abs(diff) < 0.005 ? 'Account targets match the company target.' : `Account targets are <b>${D.fmtM(Math.abs(diff))} ${diff > 0 ? 'above' : 'below'}</b> the company target${diff > 0 ? ' (stretch / over-allocation)' : ' (under-allocated)'}.`);
  }
  function renderChart() {
    const rows = baseRows(true), selQs = D.quartersFor(state.f.period);
    const groups = ['Q1', 'Q2', 'Q3', 'Q4', 'H1', 'H2', 'YTD'].map(p => { const qs = D.quartersFor(p); return { p, ...D.aggregate(rows.filter(r => qs.includes(r.quarter))) }; });
    const max = Math.max(0.01, ...groups.flatMap(g => [g.target, g.be]));
    $('#qChart').innerHTML = groups.map((g, i) => {
      const st = D.statusFor(g, state.rules);
      const active = state.f.period === 'FY' || g.p === state.f.period || (g.p.startsWith('Q') && selQs.includes(g.p));
      return `<div class="cgroup ${i === 4 ? 'sep' : ''} ${active ? '' : 'dim'}" data-p="${g.p}" title="${g.p}: Target ${D.fmtM(g.target)} · BE ${D.fmtM(g.be)} · Gap ${D.fmtGap(g.gap)}">
        <div class="cbars"><div class="cbar t" style="height:${(g.target / max) * 88}%"><span>${g.target.toFixed(1)}</span></div><div class="cbar b" style="height:${(g.be / max) * 88}%"><span>${g.be.toFixed(1)}</span></div></div>
        <div class="cdot" style="background:${st.color}"></div><div class="clabel">${g.p}</div></div>`;
    }).join('');
    $$('#qChart .cgroup').forEach(el => el.onclick = () => { state.f.period = el.dataset.p; render(); });
  }
  function renderGauge(t, st, accts) {
    const pct = Math.max(0, Math.min(120, t.attainment || 0)), ang = (pct / 120) * 180, r = 80, cx = 100, cy = 95;
    const pt = a => [cx - r * Math.cos(a * Math.PI / 180), cy - r * Math.sin(a * Math.PI / 180)];
    const [x, y] = pt(ang), [mx, my] = pt(150);
    $('#gauge').innerHTML = `<svg width="200" height="112" viewBox="0 0 200 112">
      <path d="M20 95 A80 80 0 0 1 180 95" fill="none" stroke="#e9eef5" stroke-width="16" stroke-linecap="round"/>
      <path d="M20 95 A80 80 0 0 1 ${x.toFixed(1)} ${y.toFixed(1)}" fill="none" stroke="${st.color}" stroke-width="16" stroke-linecap="round"/>
      <circle cx="${mx.toFixed(1)}" cy="${my.toFixed(1)}" r="3" fill="#0b2545"/>
      <text x="100" y="88" text-anchor="middle" font-family="Plus Jakarta Sans,Segoe UI,sans-serif" font-weight="800" font-size="26" letter-spacing="-1" fill="#0f1d33">${D.fmtPct(t.attainment)}</text>
      <text x="100" y="106" text-anchor="middle" font-family="Plus Jakarta Sans,Segoe UI,sans-serif" font-size="10" fill="#5f6f86">● = 100% marker</text></svg>`;
    const ob = $('#overallStatus'); ob.textContent = st.name; ob.style.background = st.color; ob.style.color = '#fff';
    const dist = new Map(); accts.forEach(a => dist.set(a.status.name, { c: (dist.get(a.status.name)?.c || 0) + 1, color: a.status.color }));
    $('#statusDist').innerHTML = [...dist].map(([n, v]) => `<span class="pill" style="background:${v.color}">${esc(n)} · ${v.c}</span>`).join('') || '<span class="muted">No accounts</span>';
  }
  function itemRow({ color, title, sub, val, valColor, pct, onclick }) {
    return `<div class="row-item" ${onclick ? `data-acct="${esc(onclick)}"` : ''}><span class="ri-dot" style="background:${color}"></span>
      <div class="ri-main"><div class="ri-title">${esc(title)}</div><div class="ri-sub">${sub}</div>${pct !== undefined ? `<div class="bar"><i style="width:${Math.min(100, Math.max(0, pct || 0))}%;background:${color}"></i></div>` : ''}</div>
      <div class="ri-val" style="color:${valColor || 'inherit'}">${val}</div></div>`;
  }
  const bindAcctClicks = el => $$('[data-acct]', el).forEach(n => n.onclick = () => openAccount(n.dataset.acct));
  function renderLeaders(rows) {
    const list = [...D.groupBy(rows, 'leader')].map(([leader, rs]) => { const a = D.aggregate(rs); return { leader, ...a, st: D.statusFor(a, state.rules), n: new Set(rs.map(r => r.account)).size }; }).sort((a, b) => b.target - a.target);
    const tot = D.aggregate(rows), tst = D.statusFor(tot, state.rules);
    $('#leaderList').innerHTML = itemRow({ color: tst.color, title: `Overall — ${CONFIG.overallLeader}`, sub: `${D.fmtM(tot.be)} BE of ${D.fmtM(tot.target)} · ${esc(tst.name)}`, val: D.fmtGap(tot.gap), valColor: tot.gap > 0 ? 'var(--red)' : 'var(--green)', pct: tot.attainment }) +
      list.map(l => `<div class="row-item" data-leader="${esc(l.leader)}"><span class="ri-dot" style="background:${l.st.color}"></span>
        <div class="ri-main"><div class="ri-title">${esc(l.leader)}</div><div class="ri-sub">${l.n} accounts · ${D.fmtM(l.be)} BE of ${D.fmtM(l.target)} · ${esc(l.st.name)}</div>
        <div class="bar"><i style="width:${Math.min(100, l.attainment || 0)}%;background:${l.st.color}"></i></div></div>
        <div class="ri-val" style="color:${l.gap > 0 ? 'var(--red)' : 'var(--green)'}">${D.fmtGap(l.gap)}<div class="ri-sub">${D.fmtPct(l.attainment)}</div></div></div>`).join('');
    $$('#leaderList [data-leader]').forEach(n => n.onclick = () => { state.f.leader = n.dataset.leader; render(); });
  }
  function renderRisk(accts) {
    const r = accts.filter(a => !a.status.onTrack).sort((a, b) => (b.lost - a.lost) || (b.gap - a.gap));
    $('#riskCount').textContent = `${r.length} off track`;
    $('#riskList').innerHTML = r.slice(0, 7).map(a => itemRow({ color: a.status.color, title: a.account, sub: `${esc(a.leader)} · ${esc(a.status.name)} · ${D.fmtPct(a.attainment)}`, val: D.fmtGap(a.gap), valColor: 'var(--red)', onclick: a.account })).join('') || '<div class="empty">🎉 Every account is on track for this view.</div>';
    bindAcctClicks($('#riskList'));
  }
  function renderTop(accts) {
    const t = accts.filter(a => a.target > 0 && !a.lost).sort((a, b) => b.attainment - a.attainment).slice(0, 5);
    $('#topList').innerHTML = t.map(a => itemRow({ color: a.status.color, title: a.account, sub: `${esc(a.leader)} · ${D.fmtM(a.be)} BE`, val: D.fmtPct(a.attainment), valColor: 'var(--green)', pct: a.attainment, onclick: a.account })).join('') || '<div class="empty">No data</div>';
    bindAcctClicks($('#topList'));
  }
  function renderNN(accts) {
    const n = accts.filter(a => /net new|^nn/i.test(a.accountType));
    $('#nnList').innerHTML = n.map(a => itemRow({ color: a.status.color, title: a.account, sub: `${esc(a.accountType)} · ${esc(a.leader)} · target ${D.fmtM(a.target)}`, val: D.fmtM(a.be), pct: a.attainment, onclick: a.account })).join('') || '<div class="empty">No net-new targets in this view. Mark accounts as "Net New BFSI" / "Net New PS" in the Account type column.</div>';
    bindAcctClicks($('#nnList'));
  }
  function renderAccountsTable(accts, total) {
    const q = state.search.toLowerCase(), { key, dir } = state.sort;
    const list = accts.filter(a => !q || `${a.account} ${a.leader} ${a.area} ${a.accountType}`.toLowerCase().includes(q));
    list.sort((a, b) => { const x = key === 'status' ? a.status.name : a[key], y = key === 'status' ? b.status.name : b[key]; return (typeof x === 'string' ? x.localeCompare(y) : (x ?? -1e9) - (y ?? -1e9)) * dir; });
    const cols = [['account', 'Account'], ['accountType', 'Type'], ['area', 'Area'], ['leader', 'Leader'], ['target', 'Target', 1], ['be', 'BE', 1], ['gap', 'Gap', 1], ['attainment', 'Attain.', 1], ['status', 'Status']];
    const allRows = baseRows(true);
    $('#acctTable').innerHTML = `<thead><tr>${cols.map(([k, l, n]) => `<th class="${n ? 'num' : ''}" data-k="${k}">${l}${key === k ? (dir > 0 ? ' ▲' : ' ▼') : ''}</th>`).join('')}${D.QUARTERS.map(qq => `<th class="num">${qq} gap</th>`).join('')}</tr></thead><tbody>` +
      list.map(a => {
        const qg = D.QUARTERS.map(qq => { const g = D.aggregate(allRows.filter(r => r.account === a.account && r.quarter === qq)), s = D.statusFor(g, state.rules); return `<td class="num"><span class="pill out"><i style="background:${s.color}"></i>${g.target || g.be ? D.fmtGap(g.gap) : '—'}</span></td>`; }).join('');
        return `<tr data-acct="${esc(a.account)}" style="cursor:pointer"><td><b>${esc(a.account)}</b></td><td>${esc(a.accountType)}</td><td>${esc(a.area)}</td><td>${esc(a.leader)}</td>
          <td class="num">${D.fmtM(a.target)}</td><td class="num">${D.fmtM(a.be)}</td><td class="num ${a.gap > 0 ? 'pos' : 'neg'}">${D.fmtGap(a.gap)}</td><td class="num">${D.fmtPct(a.attainment)}</td>
          <td><span class="pill" style="background:${a.status.color}">${esc(a.status.name)}</span></td>${qg}</tr>`;
      }).join('') +
      `<tr class="total"><td>Total (${list.length})</td><td></td><td></td><td>${esc(state.f.leader === 'All' ? CONFIG.overallLeader : state.f.leader)}</td><td class="num">${D.fmtM(total.target)}</td><td class="num">${D.fmtM(total.be)}</td><td class="num">${D.fmtGap(total.gap)}</td><td class="num">${D.fmtPct(total.attainment)}</td><td></td>${D.QUARTERS.map(() => '<td></td>').join('')}</tr></tbody>`;
    $$('#acctTable th[data-k]').forEach(th => th.onclick = () => { state.sort = { key: th.dataset.k, dir: state.sort.key === th.dataset.k ? -state.sort.dir : -1 }; render(); });
    bindAcctClicks($('#acctTable'));
  }
  function renderLeaderTable() {
    const rows = baseRows(true, true), periods = ['Q1', 'Q2', 'H1', 'Q3', 'Q4', 'H2', 'YTD', 'FY'];
    const cell = rs => { const a = D.aggregate(rs), s = D.statusFor(a, state.rules); return `<td class="num"><span class="pill out" title="Target ${D.fmtM(a.target)} · BE ${D.fmtM(a.be)}"><i style="background:${s.color}"></i>${D.fmtGap(a.gap)}</span><div class="ri-sub">${D.fmtPct(a.attainment)}</div></td>`; };
    const line = (name, rs, cls = '') => `<tr class="${cls}"><td><b>${esc(name)}</b></td>${periods.map(p => cell(rs.filter(r => D.quartersFor(p).includes(r.quarter)))).join('')}</tr>`;
    $('#overallLeaderBadge').textContent = `Overall · ${CONFIG.overallLeader}`;
    $('#leaderTable').innerHTML = `<thead><tr><th>Leader</th>${periods.map(p => `<th class="num">${p} gap</th>`).join('')}</tr></thead><tbody>` +
      [...new Set(rows.map(r => r.leader))].sort().map(l => line(l, rows.filter(r => r.leader === l))).join('') + line(`Overall — ${CONFIG.overallLeader}`, rows, 'total') + '</tbody>';
  }
  function renderCommitments() {
    $('#cAccount').innerHTML = [...new Set(state.records.filter(r => r.fiscalYear === state.f.fy).map(r => r.account))].sort().map(a => `<option>${esc(a)}</option>`).join('');
    const list = [...state.commitments].sort((a, b) => b.week.localeCompare(a.week));
    $('#commitTable').innerHTML = `<thead><tr><th>Week ending</th><th>Account</th><th>Leader</th><th class="num">Amount</th><th>Note</th><th>By</th></tr></thead><tbody>` +
      (list.map(c => `<tr><td>${esc(c.week)}</td><td>${esc(c.account)}</td><td>${esc(c.leader)}</td><td class="num">${D.fmtM(c.amount)}</td><td>${esc(c.note)}</td><td class="muted">${esc(c.by)}</td></tr>`).join('') || '<tr><td colspan="6" class="empty">No commitments logged yet.</td></tr>') + '</tbody>';
  }
  function renderInsight(t, accts) {
    const off = accts.filter(a => !a.status.onTrack && !a.lost).sort((a, b) => b.gap - a.gap), lost = accts.filter(a => a.lost);
    const top2 = [...accts].sort((a, b) => b.target - a.target).slice(0, 2), share = t.target ? (top2.reduce((s, a) => s + a.target, 0) / t.target) * 100 : 0;
    $('#aiText').innerHTML = `<strong>AI insight · ${state.f.period}:</strong> ` +
      (t.gap > 0 ? `We are <strong>${D.fmtM(t.gap)} behind</strong> plan` : `We are <strong>${D.fmtM(-t.gap)} ahead</strong> of plan`) + ` at ${D.fmtPct(t.attainment)} attainment. ` +
      (off[0] ? `Biggest gap: <strong>${esc(off[0].account)}</strong> (${D.fmtGap(off[0].gap)}, ${esc(off[0].leader)}). ` : '') +
      (lost.length ? `${lost.length} account${lost.length > 1 ? 's' : ''} marked lost. ` : '') + (top2.length === 2 ? `Top 2 accounts carry ${share.toFixed(0)}% of target.` : '');
  }
  function renderNotifications(accts) {
    const n = accts.filter(a => a.lost || (!a.status.onTrack && a.gap > 0.2));
    $('#notifCount').textContent = n.length;
    $('#notifBody').innerHTML = n.map(a => itemRow({ color: a.status.color, title: `${a.lost ? '⚫ Lost' : '🚨 Gap'} — ${a.account}`, sub: `${esc(a.leader)} · ${D.fmtGap(a.gap)} · ${state.f.period}`, val: '', onclick: a.account })).join('') || '<div class="empty">No alerts.</div>';
    bindAcctClicks($('#notifBody'));
  }

  // ─────────────────────────────────────────────
  // 💼 ACCOUNT DETAIL + POWER AUTOMATE ACTIONS
  // ─────────────────────────────────────────────
  function openAccount(name) {
    closeModal('notifModal'); state.selectedAccount = name;
    const rs = state.records.filter(r => r.fiscalYear === state.f.fy && r.account === name), fy = D.aggregate(rs), st = D.statusFor(fy, state.rules);
    $('#acctTitle').innerHTML = `${esc(name)} <span class="pill" style="background:${st.color};margin-left:8px">${esc(st.name)}</span>`;
    const q = D.QUARTERS.map(qq => { const a = D.aggregate(rs.filter(r => r.quarter === qq)), s = D.statusFor(a, state.rules), ld = rs.find(r => r.quarter === qq)?.leader || '—';
      return `<tr><td>${qq}</td><td>${esc(ld)}</td><td class="num">${D.fmtM(a.target)}</td><td class="num">${D.fmtM(a.be)}</td><td class="num ${a.gap > 0 ? 'pos' : 'neg'}">${D.fmtGap(a.gap)}</td><td class="num">${D.fmtPct(a.attainment)}</td><td><span class="pill" style="background:${s.color}">${esc(s.name)}</span></td></tr>`; }).join('');
    const h = p => D.aggregate(rs.filter(r => D.quartersFor(p).includes(r.quarter))), commits = state.commitments.filter(c => c.account === name);
    $('#acctBody').innerHTML = `<div class="muted">${esc(rs[0]?.accountType)} · ${esc(rs[0]?.area)} · ${esc(rs[0]?.geo)} · ${esc(state.f.fy)}</div>
      <div class="dq"><div><b>${D.fmtM(fy.target)}</b><small>FY target</small></div><div><b>${D.fmtM(fy.be)}</b><small>FY BE</small></div><div><b>${D.fmtGap(h('H1').gap)}</b><small>H1 gap</small></div><div><b>${D.fmtGap(h('H2').gap)}</b><small>H2 gap</small></div></div>
      <div class="table-wrap"><table class="tbl"><thead><tr><th>Qtr</th><th>Leader</th><th class="num">Target</th><th class="num">BE</th><th class="num">Gap</th><th class="num">Attain.</th><th>Status</th></tr></thead><tbody>${q}</tbody></table></div>
      ${commits.length ? `<div style="margin-top:12px"><b>Commitments</b>${commits.map(c => `<div class="ri-sub">${esc(c.week)} · ${D.fmtM(c.amount)} · ${esc(c.note)}</div>`).join('')}</div>` : ''}`;
    openModal('acctModal');
  }
  async function acctAction(action) {
    const name = state.selectedAccount, rs = baseRows(false, true).filter(r => r.account === name), a = D.aggregate(rs), st = D.statusFor(a, state.rules);
    const btn = action === 'notify' ? $('#acctNotify') : $('#acctCommit'), label = btn.textContent;
    btn.textContent = '⟳ Sending…'; btn.disabled = true;
    try {
      const r = await C.sendToPowerAutomate(action, { account: name, leader: [...new Set(rs.map(r => r.leader))].join(', '), target: a.target.toFixed(2), be: a.be.toFixed(2), gap: a.gap.toFixed(2), status: st.name, period: `${state.f.period} ${state.f.fy}`,
        subject: action === 'notify' ? `Action needed: ${name} is ${st.name} (${D.fmtGap(a.gap)})` : `Weekly commitment request: ${name}`,
        body: `${name} — ${state.f.period} ${state.f.fy}\nTarget ${D.fmtM(a.target)} · BE ${D.fmtM(a.be)} · Gap ${D.fmtGap(a.gap)} · Status ${st.name}` });
      if (!r.skipped) toast(`✅ "${action}" sent via Power Automate`);
    } catch (e) { toast(`⚠️ Power Automate: ${e.message}`); console.error(e); }
    btn.textContent = label; btn.disabled = false;
  }

  // ─────────────────────────────────────────────
  // 🎨 STATUS RULES EDITOR
  // ─────────────────────────────────────────────
  let draftRules = [];
  function openRules() { draftRules = JSON.parse(JSON.stringify(state.rules)); renderRules(); openModal('rulesModal'); }
  function renderRules() {
    const n = v => v === null || v === undefined ? '' : v;
    $('#rulesTable').innerHTML = `<thead><tr><th>#</th><th>Status</th><th>Colour</th><th>On track?</th><th>Match</th><th>Lost</th><th>No target</th><th>Attain. min %</th><th>Attain. max %</th><th>Gap min $M</th><th>Gap max $M</th><th></th></tr></thead><tbody>` +
      draftRules.map((r, i) => `<tr data-i="${i}"><td>${i + 1}</td>
        <td><input type="text" data-f="name" value="${esc(r.name)}"/></td><td><input type="color" data-f="color" value="${esc(r.color)}"/></td>
        <td><input type="checkbox" data-f="onTrack" ${r.onTrack ? 'checked' : ''}/></td>
        <td><select data-f="match"><option value="all" ${r.match === 'all' ? 'selected' : ''}>All</option><option value="any" ${r.match === 'any' ? 'selected' : ''}>Any</option></select></td>
        <td><input type="checkbox" data-f="lost" ${r.lost ? 'checked' : ''}/></td><td><input type="checkbox" data-f="noTarget" ${r.noTarget ? 'checked' : ''}/></td>
        <td><input type="number" step="any" data-f="attMin" value="${n(r.attMin)}"/></td><td><input type="number" step="any" data-f="attMax" value="${n(r.attMax)}"/></td>
        <td><input type="number" step="any" data-f="gapMin" value="${n(r.gapMin)}"/></td><td><input type="number" step="any" data-f="gapMax" value="${n(r.gapMax)}"/></td>
        <td style="white-space:nowrap"><button class="mini" data-m="-1" title="Move up">↑</button> <button class="mini" data-m="1" title="Move down">↓</button> <button class="mini del" data-del title="Remove">✕</button></td></tr>`).join('') + '</tbody>';
    $$('#rulesTable [data-f]').forEach(inp => inp.oninput = inp.onchange = () => {
      const r = draftRules[+inp.closest('tr').dataset.i], f = inp.dataset.f;
      r[f] = inp.type === 'checkbox' ? inp.checked : inp.type === 'number' ? (inp.value === '' ? null : Number(inp.value)) : inp.value;
      renderRulePreview();
    });
    $$('#rulesTable [data-m]').forEach(b => b.onclick = () => { const i = +b.closest('tr').dataset.i, j = i + +b.dataset.m; if (j < 0 || j >= draftRules.length) return; [draftRules[i], draftRules[j]] = [draftRules[j], draftRules[i]]; renderRules(); });
    $$('#rulesTable [data-del]').forEach(b => b.onclick = () => { draftRules.splice(+b.closest('tr').dataset.i, 1); renderRules(); });
    renderRulePreview();
  }
  function renderRulePreview() {
    const dist = new Map();
    accountSummaries(baseRows()).forEach(a => { const s = D.statusFor(a, draftRules); dist.set(s.name, { c: (dist.get(s.name)?.c || 0) + 1, color: s.color }); });
    $('#rulePreview').innerHTML = '<span class="muted" style="font-size:.78rem">Live preview (current view):</span> ' + [...dist].map(([k, v]) => `<span class="pill" style="background:${v.color}">${esc(k)} · ${v.c}</span>`).join('');
  }
  async function saveRules() {
    state.rules = draftRules; D.save({ rules: state.rules }); closeModal('rulesModal'); render(); toast('✅ Status rules saved');
    if (SETTINGS.source !== 'dataverse') return;
    try { const r = await C.saveStatusRulesToDataverse(state.rules); if (!r?.skipped) toast('✅ Status rules saved to Dataverse'); } catch (e) { toast('⚠️ Saved locally — Dataverse save failed'); console.error(e); }
  }

  // ═════════════════════════════════════════════
  // ⚙️ DATA SETTINGS & CONNECTIONS
  // Edits happen on a DRAFT. Each connection is tested against the draft.
  // A test result is valid only while its fields are unchanged (signature).
  // Save & load unlocks when every REQUIRED connection has passed.
  // ═════════════════════════════════════════════
  let draft = null, dsTests = {}, dsTab = 'source';

  function sigFor(conn, d) {
    switch (conn) {
      case 'dataverse': return JSON.stringify([dvInfo(d).url, (d.dataverseEntitySet || '').trim()]);
      case 'sharepoint': return JSON.stringify([d.sharepointSiteUrl.trim(), d.sharepointFilePath.trim(), d.sharepointTable.trim(), d.sharepointWorksheet, d.sharepointUploadFolder.trim(), !!d.archiveUploadsToSharePoint, d.source === 'sharepoint']);
      case 'agent': return JSON.stringify([d.agentMode, d.agentMode === 'endpoint' ? d.agentTokenEndpoint.trim() : '']);
      case 'powerAutomate': return JSON.stringify([d.paMode, d.paMode === 'url' ? d.paUrl.trim() : '', d.paMode === 'url' ? d.paAuth : '']);
    }
  }
  function requiredConns(d) {
    return { dataverse: d.source === 'dataverse', sharepoint: d.source === 'sharepoint' || !!d.archiveUploadsToSharePoint, agent: !!d.agentEnabled, powerAutomate: !!d.paEnabled };
  }
  function connState(conn, d, tests) {
    const t = tests[conn];
    if (t?.status === 'testing') return 'testing';
    if (!t || t.sig !== sigFor(conn, d)) return 'untested';
    return t.status;
  }
  function needsSignIn(d) {
    const r = requiredConns(d);
    return r.dataverse || r.sharepoint || (d.paEnabled && d.paMode === 'url' && d.paAuth === 'entra');
  }

  function openSettings(tab = 'source') {
    draft = JSON.parse(JSON.stringify(SETTINGS));
    dsTests = JSON.parse(JSON.stringify(SETTINGS.tests || {}));
    // fill form
    $('#dsArchive').checked = !!draft.archiveUploadsToSharePoint;
    $('#dsDvUrl').value = draft.dataverseUrl; $('#dsDvTable').value = draft.dataverseEntitySet;
    $('#dsSpSite').value = draft.sharepointSiteUrl; $('#dsSpFile').value = draft.sharepointFilePath;
    $('#dsSpTable').value = draft.sharepointTable; $('#dsSpFolder').value = draft.sharepointUploadFolder;
    $('#dsSpSheet').innerHTML = `<option value="">First worksheet</option>${draft.sharepointWorksheet ? `<option selected>${esc(draft.sharepointWorksheet)}</option>` : ''}`;
    $('#dsAgentOn').checked = !!draft.agentEnabled; $('#dsAgentName').value = draft.agentName || ''; $('#dsAgentEp').value = draft.agentTokenEndpoint;
    $('#dsPaOn').checked = !!draft.paEnabled; $('#dsPaUrl').value = draft.paUrl; $('#dsPaUrl').type = 'password'; $('#dsPaAuth').value = draft.paAuth || 'none';
    $('#dsPicker').classList.add('hidden');
    setTab(tab); refreshDs(); openModal('settingsModal');
  }
  function setTab(t) {
    dsTab = t;
    $$('#dsTabs .ds-tab').forEach(b => b.classList.toggle('on', b.dataset.tab === t));
    $$('.ds-pane').forEach(p => p.classList.toggle('on', p.dataset.pane === t));
  }
  function readForm() {
    Object.assign(draft, {
      archiveUploadsToSharePoint: $('#dsArchive').checked,
      dataverseUrl: $('#dsDvUrl').value.trim(), dataverseEntitySet: $('#dsDvTable').value.trim() || 'cr_salesperformances',
      sharepointSiteUrl: $('#dsSpSite').value.trim().replace(/\/+$/, ''), sharepointFilePath: $('#dsSpFile').value.trim().replace(/^\/+/, ''),
      sharepointTable: $('#dsSpTable').value.trim(), sharepointWorksheet: $('#dsSpSheet').value,
      sharepointUploadFolder: $('#dsSpFolder').value.trim() || 'SalesDashboard/Incoming',
      agentEnabled: $('#dsAgentOn').checked, agentName: $('#dsAgentName').value.trim() || 'Sales Performance Agent', agentTokenEndpoint: $('#dsAgentEp').value.trim(),
      paEnabled: $('#dsPaOn').checked, paUrl: $('#dsPaUrl').value.trim(), paAuth: $('#dsPaAuth').value
    });
  }
  const STATE_TEXT = { ok: 'Connected', fail: 'Failed', untested: 'Not tested', testing: 'Testing…', off: 'Off' };
  function refreshDs() {
    const req = requiredConns(draft);
    // source cards
    $$('#srcGrid .src').forEach(t => { const on = t.dataset.src === draft.source; t.classList.toggle('on', on); t.querySelector('input').checked = on; });
    $$('[data-srcst]').forEach(el => { const c = el.dataset.srcst, s = connState(c, draft, dsTests); el.innerHTML = `<span class="dot ${s}"></span>${STATE_TEXT[s]} · <a href="#" data-goto="${c}">configure →</a>`; });
    $$('[data-goto]').forEach(a => a.onclick = e => { e.preventDefault(); e.stopPropagation(); setTab(a.dataset.goto); });
    // modes
    $$('#dsAgentMode button').forEach(b => b.classList.toggle('on', b.dataset.v === draft.agentMode));
    $$('[data-agentmode]').forEach(el => el.classList.toggle('hidden', el.dataset.agentmode !== draft.agentMode));
    $$('#dsPaMode button').forEach(b => b.classList.toggle('on', b.dataset.v === draft.paMode));
    $$('[data-pamode]').forEach(el => el.classList.toggle('hidden', el.dataset.pamode !== draft.paMode));
    // tab dots + result boxes
    CONNS.forEach(c => {
      const s = connState(c, draft, dsTests), t = dsTests[c];
      const used = req[c], shown = !used && s === 'untested' ? 'off' : s;
      $(`[data-dot="${c}"]`).className = `dot ${shown}`;
      const box = $(`[data-result="${c}"]`);
      box.className = `test-result ${s === 'untested' && !used ? '' : s}`;
      if (s === 'testing') box.innerHTML = '⟳ Testing the connection…';
      else if (s === 'untested') box.innerHTML = t ? '✎ Settings changed since the last test — test again.' : (used ? '⚠ Not tested yet — required before Save &amp; load.' : 'Not tested. Optional unless this connection is in use.');
      else box.innerHTML = `${s === 'ok' ? '✓' : '✕'} ${esc(t.msg)}<small>Tested ${new Date(t.at).toLocaleTimeString('en-ZA', { hour: '2-digit', minute: '2-digit' })}</small>`;
      const btn = $(`[data-test="${c}"]`); btn.disabled = s === 'testing';
    });
    $('[data-test="agent"]').disabled ||= !draft.agentEnabled;
    $('[data-test="powerAutomate"]').disabled ||= !draft.paEnabled;
    // sign-in note
    const showSign = needsSignIn(draft) && !C.isSignedIn();
    $('#dsSignin').classList.toggle('hidden', !showSign);
    $('#dsSigninText').textContent = ENTRA.canRun ? 'Dataverse, SharePoint and tenant-only flows need you to sign in with your LTM Microsoft account before testing.'
      : 'Microsoft sign-in only works when the dashboard is opened from Netlify or http://localhost. As a local file you can still test the Copilot agent (token endpoint) and Power Automate (anyone-with-URL).';
    $('#dsSigninBtn').classList.toggle('hidden', !ENTRA.canRun);
    // requirements + save gate
    const items = CONNS.filter(c => req[c]).map(c => ({ c, s: connState(c, draft, dsTests) }));
    $('#reqList').innerHTML = items.length
      ? items.map(({ c, s }) => `<span class="req ${s === 'ok' ? 'ok' : s === 'fail' ? 'bad' : 'wait'}">${s === 'ok' ? '✓' : s === 'fail' ? '✕' : '•'} ${CONN_NAMES[c]}</span>`).join('')
      : '<span class="req ok">✓ No connections required</span>';
    const ready = items.every(i => i.s === 'ok');
    $('#dsSave').disabled = !ready;
    $('#dsSave').title = ready ? 'Save settings and load data' : 'Test every required connection first: ' + items.filter(i => i.s !== 'ok').map(i => CONN_NAMES[i.c]).join(', ');
  }
  async function runTest(conn) {
    readForm();
    const sig = sigFor(conn, draft), snapshot = JSON.parse(JSON.stringify(draft));
    dsTests[conn] = { status: 'testing', sig }; refreshDs();
    let r;
    try {
      r = conn === 'dataverse' ? await C.testDataverse(snapshot)
        : conn === 'sharepoint' ? await C.testSharePoint(snapshot, { requireFile: snapshot.source === 'sharepoint' })
        : conn === 'agent' ? await C.testAgent(snapshot)
        : await C.testPowerAutomate(snapshot);
    } catch (e) { r = { ok: false, msg: e.message }; }
    dsTests[conn] = { status: r.ok ? 'ok' : 'fail', sig, msg: r.msg, at: new Date().toISOString() };
    if (conn === 'sharepoint' && r.ok && snapshot.sharepointFilePath) loadWorksheets(snapshot);
    if ($('#settingsModal').classList.contains('open')) refreshDs();
    return r.ok;
  }
  async function testAll() {
    readForm();
    const req = requiredConns(draft);
    const list = CONNS.filter(c => req[c] || (c === 'dataverse' && dvInfo(draft).isConfigured) || (c === 'sharepoint' && spInfo(draft).isConfigured));
    if (!list.length) return toast('Nothing to test — add a connection first');
    $('#dsTestAll').disabled = true;
    const res = await Promise.all(list.map(runTest));
    $('#dsTestAll').disabled = false;
    toast(res.every(Boolean) ? `✅ All ${list.length} connection(s) passed` : `⚠️ ${res.filter(x => !x).length} of ${list.length} connection(s) failed — see the tabs marked red`);
  }
  async function loadWorksheets(d) {
    try {
      const sheets = await C.listWorksheets(spInfo(d)), cur = $('#dsSpSheet').value;
      $('#dsSpSheet').innerHTML = `<option value="">First worksheet</option>` + sheets.map(s => `<option ${s === cur ? 'selected' : ''}>${esc(s)}</option>`).join('');
    } catch (e) { console.warn('Worksheets:', e.message); }
  }
  async function browse(folder) {
    readForm();
    const p = $('#dsPicker'), sp = spInfo(draft);
    try {
      if (!sp.isConfigured) throw new Error('Enter the site URL first');
      p.classList.remove('hidden'); p.innerHTML = '<div class="pi">⟳ Loading…</div>';
      const items = await C.listSharePointFiles(folder, sp);
      const up = folder ? `<div class="pi" data-folder="${esc(folder.split('/').slice(0, -1).join('/'))}">⬆ Up one level</div>` : '';
      p.innerHTML = `<div class="pi" style="cursor:default;font-weight:700">📂 Documents/${esc(folder)}</div>` + up +
        (items.map(i => i.isFolder ? `<div class="pi" data-folder="${esc(i.path)}">📁 ${esc(i.name)}</div>`
          : `<div class="pi" data-file="${esc(i.path)}">📄 ${esc(i.name)}<small>${new Date(i.modified).toLocaleDateString('en-ZA')}</small></div>`).join('') || '<div class="pi">No Excel files here</div>');
      $$('[data-folder]', p).forEach(el => el.onclick = () => browse(el.dataset.folder));
      $$('[data-file]', p).forEach(el => el.onclick = () => { $('#dsSpFile').value = el.dataset.file; p.classList.add('hidden'); readForm(); refreshDs(); runTest('sharepoint'); });
    } catch (e) { p.classList.add('hidden'); dsTests.sharepoint = { status: 'fail', sig: sigFor('sharepoint', draft), msg: e.message, at: new Date().toISOString() }; refreshDs(); }
  }
  async function saveDataSettings() {
    readForm(); refreshDs();
    if ($('#dsSave').disabled) return toast('Test every required connection before saving');
    const changedAgent = sigFor('agent', draft) !== sigFor('agent', SETTINGS) || draft.agentEnabled !== SETTINGS.agentEnabled;
    saveSettings({ ...draft, tests: dsTests });
    closeModal('settingsModal');
    toast(`✅ Saved · data source: ${SOURCE_NAMES[SETTINGS.source]}`);
    if (changedAgent) window.Agent.reset();
    await loadData();
  }
  function updateConnDots() {
    const req = requiredConns(SETTINGS), dots = $$('#connDots i');
    CONNS.forEach((c, i) => {
      const s = req[c] ? connState(c, SETTINGS, SETTINGS.tests || {}) : 'off';
      dots[i].className = s === 'off' ? '' : s; dots[i].title = `${CONN_NAMES[c]}: ${STATE_TEXT[s]}`;
    });
    $('#connDots').title = CONNS.map((c, i) => dots[i].title).join(' · ');
  }

  // ─────────────────────────────────────────────
  // 📥 UPLOAD WIZARD
  // ─────────────────────────────────────────────
  const up = { step: 1, file: null, wb: null, sheet: null, a: null, map: null, result: null };
  const FIELD_LABELS = { account: 'Account', area: 'Area', geo: 'Geo', accountType: 'Account type', leader: 'Sales leader / A.O', fiscalYear: 'Fiscal year', quarter: 'Quarter', target: 'Target / Budget', be: 'BE / Forecast', lost: 'Lost flag', marginTarget: 'Margin target', actualMargin: 'Actual margin' };
  function openUpload() { Object.assign(up, { step: 1, file: null, wb: null, a: null, result: null }); $('#fileInput').value = ''; showStep(1); openModal('uploadModal'); }
  function showStep(n) {
    up.step = n;
    $$('.up-step').forEach(s => s.classList.toggle('hidden', +s.dataset.step !== n));
    $$('#upSteps span').forEach((s, i) => { s.classList.toggle('on', i + 1 === n); s.classList.toggle('done', i + 1 < n); });
    $('#upBack').style.visibility = n > 1 ? 'visible' : 'hidden';
    $('#upNext').textContent = n === 3 ? 'Import' : 'Next';
    $('#upNext').disabled = n === 1 ? !up.wb : n === 3 ? !(up.result && up.result.records.length && !up.result.errors.length) : false;
    $('#upAskAgent').style.visibility = n > 1 ? 'visible' : 'hidden';
  }
  async function handleFile(file) {
    if (!file) return;
    if (!/\.(xlsx|xlsm|xls|csv)$/i.test(file.name)) { toast('⚠️ Please choose an .xlsx, .xls, .xlsm or .csv file'); return; }
    try {
      up.file = file; up.wb = await window.Upload.readWorkbook(file);
      let best = up.wb.SheetNames[0], bestScore = -1;
      up.wb.SheetNames.forEach(s => { const a = window.Upload.analyse(window.Upload.sheetToGrid(up.wb, s)); const sc = a.rows.length + (a.map.account >= 0 ? 1000 : 0); if (sc > bestScore) { bestScore = sc; best = s; } });
      $('#upSheet').innerHTML = up.wb.SheetNames.map(s => `<option ${s === best ? 'selected' : ''}>${esc(s)}</option>`).join('');
      $('#upFY').value = state.f.fy; analyseSheet(best, null); showStep(2);
    } catch (e) { toast('⚠️ ' + e.message); }
  }
  function analyseSheet(sheet, headerRowOverride) {
    up.sheet = sheet;
    const grid = window.Upload.sheetToGrid(up.wb, sheet);
    let a = window.Upload.analyse(grid);
    if (headerRowOverride) { const hr = Math.max(0, headerRowOverride - 1); a = window.Upload.analyse(grid.slice(hr)); a.headerRow += hr; }
    up.a = a; up.map = { ...a.map };
    $('#upHeaderRow').value = a.headerRow + 1; $('#upFormat').value = a.format;
    const maxVal = Math.max(0, ...a.rows.flat().filter(v => typeof v === 'number'));
    $('#upDiv').value = maxVal > 100000 ? '1000000' : maxVal > 1000 ? '1000' : '1';
    $('#upMeta').innerHTML = `<b>${esc(up.file.name)}</b> · ${(up.file.size / 1024).toFixed(0)} KB · sheet "${esc(sheet)}" · header on row ${a.headerRow + 1} · ${a.rows.length} data rows · detected <b>${a.format === 'wide' ? 'wide (Q1–Q4 across columns)' : 'long (one row per quarter)'}</b> layout`;
    renderMapping();
  }
  function renderMapping() {
    const a = up.a, fmt = $('#upFormat').value, req = fmt === 'long' ? ['account', 'quarter', 'target', 'be'] : ['account'];
    const fields = fmt === 'wide' ? ['account', 'area', 'geo', 'accountType', 'leader', 'lost'] : window.Upload.FIELDS;
    $('#mapGrid').innerHTML = fields.map(f => `<label class="${req.includes(f) ? 'req' : ''}">${FIELD_LABELS[f]}
      <select data-map="${f}" class="${a.map[f] >= 0 ? 'auto' : ''}"><option value="-1">— not in file —</option>${a.headers.map((h, i) => `<option value="${i}" ${up.map[f] === i ? 'selected' : ''}>${esc(h)}</option>`).join('')}</select></label>`).join('');
    $$('#mapGrid select').forEach(s => s.onchange = () => { up.map[s.dataset.map] = +s.value; });
    $('#wideInfo').innerHTML = fmt === 'wide'
      ? (a.wideGroups ? '🧭 Quarter columns detected: ' + a.wideGroups.map(g => `<b>${g.quarter}${g.fy ? ' ' + g.fy : ''}</b> → Target: ${g.target !== undefined ? esc(a.headers[g.target]) : '—'}, BE: ${g.be !== undefined ? esc(a.headers[g.be]) : '—'}${g.leader !== undefined ? ', Leader: ' + esc(a.headers[g.leader]) : ''}`).join(' · ') : '⚠️ No Q1–Q4 columns found. Switch to Long layout or rename headers like "Q1 Target" / "Q1 BE".')
      : '💡 Long layout: each row is one account in one quarter (Q1–Q4). Leader per row supports mid-year ownership changes.';
  }
  const buildOpts = () => ({ format: $('#upFormat').value, map: up.map, wideGroups: up.a.wideGroups || [], unitDivisor: $('#upDiv').value, defaultFY: $('#upFY').value.trim() || state.f.fy });
  const toDataverse = () => SETTINGS.source === 'dataverse' && dvInfo().isConfigured && C.isSignedIn();
  const toSharePoint = () => (SETTINGS.archiveUploadsToSharePoint || SETTINGS.source === 'sharepoint') && spInfo().isConfigured && C.isSignedIn();
  function buildPreview() {
    up.result = window.Upload.buildRecords(up.a, buildOpts());
    const { records, errors, warnings } = up.result, agg = D.aggregate(records);
    $('#valSummary').innerHTML = `<div class="box ok">✅ <b>${records.length}</b> records · <b>${new Set(records.map(r => r.account)).size}</b> accounts · FY ${[...new Set(records.map(r => r.fiscalYear))].join(', ') || '—'} · Target ${D.fmtM(agg.target)} · BE ${D.fmtM(agg.be)}</div>` +
      (errors.length ? `<div class="box err">❌ <b>${errors.length} error(s)</b> — fix the mapping or the file<ul>${errors.slice(0, 30).map(e => `<li>${esc(e)}</li>`).join('')}</ul></div>` : '') +
      (warnings.length ? `<div class="box warn">⚠️ <b>${warnings.length} warning(s)</b><ul>${warnings.slice(0, 30).map(e => `<li>${esc(e)}</li>`).join('')}</ul></div>` : '');
    $('#previewTable').innerHTML = `<thead><tr><th>Account</th><th>Type</th><th>Area</th><th>Leader</th><th>FY</th><th>Qtr</th><th class="num">Target</th><th class="num">BE</th><th>Lost</th></tr></thead><tbody>` +
      records.slice(0, 60).map(r => `<tr><td>${esc(r.account)}</td><td>${esc(r.accountType)}</td><td>${esc(r.area)}</td><td>${esc(r.leader)}</td><td>${esc(r.fiscalYear)}</td><td>${r.quarter}</td><td class="num">${r.target.toFixed(3)}</td><td class="num">${r.be.toFixed(3)}</td><td>${r.lost ? '⚫' : ''}</td></tr>`).join('') + '</tbody>';
    $('#destList').innerHTML = [['💾 This browser', true], ['🗄️ Dataverse table', toDataverse()], ['📁 SharePoint archive', toSharePoint()], ['📨 Power Automate notice', paInfo().isConfigured]]
      .map(([n, on]) => `<span>${n}: <b style="color:${on ? 'var(--green)' : 'var(--muted)'}">${on ? 'yes' : 'no'}</b></span>`).join('');
  }
  function agentPayload() {
    const r = up.result || window.Upload.buildRecords(up.a, buildOpts());
    return { fileName: up.file?.name, sheet: up.sheet, format: $('#upFormat').value, headerRow: up.a.headerRow + 1, headers: up.a.headers, sampleRows: up.a.rows.slice(0, 5),
      mapping: Object.fromEntries(Object.entries(up.map).map(([k, v]) => [k, v >= 0 ? up.a.headers[v] : '—'])), records: r.records.length, errors: r.errors, warnings: r.warnings };
  }
  async function doImport() {
    const btn = $('#upNext'); btn.disabled = true; btn.textContent = '⟳ Importing…';
    const { records } = up.result, mode = $('input[name=upMode]:checked').value, fys = new Set(records.map(r => r.fiscalYear)), m = new Map();
    records.forEach(r => { const k = `${r.fiscalYear}|${r.account}|${r.quarter}`; if (m.has(k)) { const x = m.get(k); x.target += r.target; x.be += r.be; } else m.set(k, { ...r }); });
    const clean = [...m.values()], existing = state.source === 'demo' ? [] : state.records;
    state.records = mode === 'replace' ? [...existing.filter(r => !fys.has(r.fiscalYear)), ...clean] : [...existing, ...clean];
    D.save({ records: state.records, lastImport: { file: up.file.name, at: new Date().toISOString(), rows: clean.length } });
    state.f.fy = [...fys][0] || state.f.fy;
    finish(state.records, 'saved'); closeModal('uploadModal'); toast(`✅ Imported ${clean.length} records from ${up.file.name}`);
    const batch = `${up.file.name} · ${new Date().toLocaleString('en-ZA')}`;
    if (toSharePoint()) { try { await C.uploadToSharePoint(up.file); toast('📁 File archived to SharePoint'); } catch (e) { toast('⚠️ SharePoint archive failed'); console.error(e); } }
    if (toDataverse()) {
      try { const d = await C.saveRecordsToDataverse(clean, batch); toast(`🗄️ ${d.created} rows saved to Dataverse`); await loadData(); }
      catch (e) { toast('⚠️ Dataverse save failed — data kept in this browser'); console.error(e); }
    }
    if (paInfo().isConfigured) C.sendToPowerAutomate('import_completed', { subject: `Sales data imported: ${up.file.name}`, body: `${clean.length} records imported (${mode}).` }).catch(console.error);
    window.Agent.sendContext();
  }

  // ─────────────────────────────────────────────
  // ⤓ EXPORT
  // ─────────────────────────────────────────────
  function exportCSV() {
    const head = ['Account', 'Account type', 'Area', 'Leader', 'Period', 'Fiscal year', 'Target ($M)', 'BE ($M)', 'Gap ($M)', 'Attainment %', 'Status'];
    const lines = accountSummaries(baseRows()).map(a => [a.account, a.accountType, a.area, a.leader, state.f.period, state.f.fy, a.target.toFixed(3), a.be.toFixed(3), a.gap.toFixed(3), a.attainment?.toFixed(1) ?? '', a.status.name]);
    const csv = [head, ...lines].map(r => r.map(v => `"${String(v).replace(/"/g, '""')}"`).join(',')).join('\r\n');
    const url = URL.createObjectURL(new Blob(['\ufeff' + csv], { type: 'text/csv' }));
    Object.assign(document.createElement('a'), { href: url, download: `LTM_Sales_${state.f.fy}_${state.f.period}.csv` }).click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  // ─────────────────────────────────────────────
  // 🤖 CONTEXT FOR THE AGENT
  // ─────────────────────────────────────────────
  function getContext() {
    const rows = baseRows(), t = D.aggregate(rows), accts = accountSummaries(rows);
    return { fiscalYear: state.f.fy, period: state.f.period, quarters: D.quartersFor(state.f.period),
      leader: state.f.leader === 'All' ? `Overall (${CONFIG.overallLeader})` : state.f.leader, accountType: state.f.type, area: state.f.area,
      dataSource: state.source === 'demo' ? 'Demo data' : SOURCE_NAMES[SETTINGS.source], companyTarget: D.fmtM(CONFIG.companyTarget),
      kpis: { target: D.fmtM(t.target), be: D.fmtM(t.be), gap: D.fmtGap(t.gap), attainment: D.fmtPct(t.attainment), onTrack: accts.filter(a => a.status.onTrack).length, lost: accts.filter(a => a.lost).length, accounts: accts.length },
      offTrack: accts.filter(a => !a.status.onTrack).sort((a, b) => b.gap - a.gap).map(a => ({ account: a.account, leader: a.leader, gap: D.fmtGap(a.gap), attainment: D.fmtPct(a.attainment), status: a.status.name })),
      statusRules: state.rules.map(({ name, color, lost, noTarget, attMin, attMax, gapMin, gapMax, match }) => ({ name, color, lost, noTarget, attMin, attMax, gapMin, gapMax, match })),
      gapDefinition: 'Gap = Target − BE; positive = behind, negative = ahead' };
  }

  // ─────────────────────────────────────────────
  // 🎛️ EVENTS
  // ─────────────────────────────────────────────
  function setView(v) { state.view = v; $$('.view').forEach(s => s.classList.toggle('hidden', s.id !== `view-${v}`)); $$('.nav-item[data-view]').forEach(n => n.classList.toggle('active', n.dataset.view === v)); }
  function bind() {
    $('#fFY').onchange = e => { state.f.fy = e.target.value; render(); };
    $('#fLeader').onchange = e => { state.f.leader = e.target.value; render(); };
    $('#fType').onchange = e => { state.f.type = e.target.value; render(); };
    $('#fArea').onchange = e => { state.f.area = e.target.value; render(); };
    $$('#fPeriod button').forEach(b => b.onclick = () => { state.f.period = b.dataset.p; render(); });
    $('#btnReset').onclick = () => { Object.assign(state.f, { period: 'FY', leader: 'All', type: 'All', area: 'All' }); render(); };
    $('#acctSearch').oninput = e => { state.search = e.target.value; renderAccountsTable(accountSummaries(baseRows()), D.aggregate(baseRows())); };
    $$('.nav-item[data-view]').forEach(n => n.onclick = () => setView(n.dataset.view));
    $$('.nav-item[data-action]').forEach(n => n.onclick = () => ({ upload: openUpload, rules: openRules, agent: window.Agent.toggle, settings: () => openSettings() }[n.dataset.action])());
    $('#btnUpload').onclick = openUpload; $('#btnRules').onclick = openRules; $('#btnExport').onclick = exportCSV;
    $('#btnSettings').onclick = () => openSettings(); $('#dataStatusBadge').onclick = () => openSettings();
    $('#connDots').onclick = () => openSettings('dataverse');
    $('#btnNotif').onclick = () => openModal('notifModal');
    $('#aiInsight').onclick = () => { window.Agent.open(); setTimeout(() => window.Agent.ask('Summarise performance for the current view and recommend the top 3 actions.'), 400); };
    $('#agentFab').onclick = window.Agent.open; $('#btnAgentClose').onclick = window.Agent.close;
    $('#btnSignIn').onclick = () => C.isSignedIn() ? C.signOut() : C.signIn();
    $('#setupOpenSettings').onclick = () => { closeModal('setupModal'); closeModal('acctModal'); openSettings('powerAutomate'); };

    // ── data settings ──
    $$('#dsTabs .ds-tab').forEach(b => b.onclick = () => setTab(b.dataset.tab));
    $$('#srcGrid .src').forEach(t => t.onclick = e => { if (e.target.closest('[data-goto]')) return; e.preventDefault(); readForm(); draft.source = t.dataset.src; refreshDs(); });
    $$('#settingsModal input, #settingsModal select').forEach(el => { if (el.name === 'dsSource') return; el.addEventListener('input', () => { readForm(); refreshDs(); }); el.addEventListener('change', () => { readForm(); refreshDs(); }); });
    $$('#dsAgentMode button').forEach(b => b.onclick = () => { readForm(); draft.agentMode = b.dataset.v; refreshDs(); });
    $$('#dsPaMode button').forEach(b => b.onclick = () => { readForm(); draft.paMode = b.dataset.v; refreshDs(); });
    $$('[data-test]').forEach(b => b.onclick = () => runTest(b.dataset.test));
    $('#dsTestAll').onclick = testAll;
    $('#dsPaShow').onclick = e => { e.preventDefault(); const i = $('#dsPaUrl'); i.type = i.type === 'password' ? 'text' : 'password'; e.target.textContent = i.type === 'password' ? 'Show' : 'Hide'; };
    $('#dsSigninBtn').onclick = () => { readForm(); saveSettings({ ...draft, tests: dsTests }); C.signIn(); };
    $('#dsSpBrowse').onclick = () => browse($('#dsSpFile').value.trim().split('/').slice(0, -1).join('/'));
    $('#dsGoUpload').onclick = () => { closeModal('settingsModal'); openUpload(); };
    $('#dsSave').onclick = saveDataSettings;
    $('#btnClearLocal').onclick = () => { if (confirm('Clear uploads, rules and commitments saved in this browser? Connection settings are kept.')) { D.clear(); state.rules = D.defaultRules(); state.commitments = []; closeModal('settingsModal'); loadData(); } };

    $$('[data-close]').forEach(b => b.onclick = () => closeModal(b.dataset.close));
    $$('.modal-overlay').forEach(el => el.addEventListener('click', e => { if (e.target === el) closeModal(el.id); }));
    document.addEventListener('keydown', e => { if (e.key === 'Escape') $$('.modal-overlay.open').forEach(m => closeModal(m.id)); });
    $('#acctNotify').onclick = () => acctAction('notify');
    $('#acctCommit').onclick = () => acctAction('request_commitment');
    $('#acctAsk').onclick = () => { closeModal('acctModal'); window.Agent.open(); setTimeout(() => window.Agent.ask(`Analyse ${state.selectedAccount} for ${state.f.period} ${state.f.fy}: why is it at this status and what should the leader do?`), 400); };
    $('#ruleAdd').onclick = () => { draftRules.push({ id: 'r-' + Date.now(), name: 'New status', color: '#3b82f6', onTrack: false, match: 'all', lost: false, noTarget: false, attMin: null, attMax: null, gapMin: null, gapMax: null }); renderRules(); };
    $('#ruleReset').onclick = () => { draftRules = D.defaultRules(); renderRules(); };
    $('#ruleSave').onclick = saveRules;
    const dz = $('#dropZone');
    $('#fileInput').onchange = e => handleFile(e.target.files[0]);
    ['dragenter', 'dragover'].forEach(ev => dz.addEventListener(ev, e => { e.preventDefault(); dz.classList.add('over'); }));
    ['dragleave', 'drop'].forEach(ev => dz.addEventListener(ev, e => { e.preventDefault(); dz.classList.remove('over'); }));
    dz.addEventListener('drop', e => handleFile(e.dataTransfer.files[0]));
    $('#upSheet').onchange = e => analyseSheet(e.target.value, null);
    $('#upHeaderRow').onchange = e => analyseSheet(up.sheet, +e.target.value);
    $('#upFormat').onchange = renderMapping;
    $('#upBack').onclick = () => showStep(up.step - 1);
    $('#upNext').onclick = () => { if (up.step === 2) { buildPreview(); showStep(3); } else if (up.step === 3) doImport(); else showStep(2); };
    $('#upAskAgent').onclick = () => window.Agent.reviewUpload(agentPayload());
    $('#commitForm').onsubmit = async e => {
      e.preventDefault();
      const f = Object.fromEntries(new FormData(e.target));
      const leader = state.records.find(r => r.account === f.account && r.fiscalYear === state.f.fy && r.quarter === D.currentFiscalQuarter())?.leader || state.records.find(r => r.account === f.account)?.leader || '—';
      const c = { account: f.account, leader, amount: Number(f.amount), week: f.week, note: f.note || '', by: C.getAccount()?.username || 'me' };
      state.commitments.push(c); D.save({ commitments: state.commitments }); renderCommitments(); e.target.reset(); toast('✅ Commitment saved');
      if (SETTINGS.source !== 'dataverse') return;
      try { const r = await C.saveCommitmentToDataverse(c); if (!r?.skipped) toast('🗄️ Commitment saved to Dataverse'); } catch (err) { console.error(err); toast('⚠️ Saved locally — Dataverse save failed'); }
    };
  }

  // ─────────────────────────────────────────────
  // 🚀 START
  // ─────────────────────────────────────────────
  async function start() {
    bind(); updateClock(); setInterval(updateClock, 30000);
    try {
      const acc = await C.initAuth();
      if (acc) {
        $('#btnSignIn').textContent = 'Sign out';
        $('#avatar').textContent = (acc.name || acc.username).split(/[\s@.]/).filter(Boolean).slice(0, 2).map(s => s[0].toUpperCase()).join('');
        $('#avatar').title = acc.name || acc.username;
      }
    } catch (e) { console.error('Auth init failed', e); toast('⚠️ Sign-in failed: ' + e.message); }
    await loadData();
    setInterval(() => { if (SETTINGS.source !== 'excel') loadData(); }, CONFIG.refreshMinutes * 60 * 1000);
  }
  window.UI = { toast, openSetupGuide, openModal, closeModal, openSettings };
  window.App = { getContext, render, state };
  document.addEventListener('DOMContentLoaded', start);
})();
