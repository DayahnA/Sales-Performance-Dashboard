/* ================================================================
   LTM-AI INTELLIGENCE DASHBOARD — CONFIGURATION
   Same connector pattern as the LTM AI Intelligence (email) dashboard:
   one block per Microsoft connector, each with an `isConfigured` check.

   Connection values come from env.js (Netlify build defaults) and are
   added / overridden by the user in ⚙️ Data settings → Connections.
   Every connection must pass "Test connection" before Save & load.
   The Entra client SECRET is never used or stored in browser code.
   ================================================================ */
const ENV = window.__ENV__ || {};
const has = (v) => typeof v === 'string' && v.trim() !== '' && !v.includes('YOUR_');
const SETTINGS_KEY = 'ltm-spd-settings-v2';

// ─────────────────────────────────────────────
// 💾 USER SETTINGS (Data settings modal)
// ─────────────────────────────────────────────
const DEFAULT_SETTINGS = {
  // Data source: 'excel' | 'dataverse' | 'sharepoint'
  source: 'excel',
  archiveUploadsToSharePoint: false,
  // Dataverse
  dataverseUrl: ENV.DATAVERSE_URL || '',
  dataverseEntitySet: 'cr_salesperformances',
  // SharePoint
  sharepointSiteUrl: ENV.SHAREPOINT_SITE_URL || '',
  sharepointFilePath: ENV.EXCEL_FILE_PATH || '',
  sharepointTable: ENV.EXCEL_TABLE_NAME || '',
  sharepointWorksheet: '',
  sharepointUploadFolder: ENV.SHAREPOINT_LIBRARY_FOLDER || 'SalesDashboard/Incoming',
  // Copilot Studio agent — mode 'endpoint' (Copilot Studio token endpoint) | 'server' (Netlify + DIRECTLINE_SECRET)
  agentEnabled: ENV.AGENT_ENABLED === 'true' || has(ENV.AGENT_TOKEN_ENDPOINT),
  agentMode: has(ENV.AGENT_TOKEN_ENDPOINT) ? 'endpoint' : (ENV.AGENT_ENABLED === 'true' ? 'server' : 'endpoint'),
  agentTokenEndpoint: ENV.AGENT_TOKEN_ENDPOINT || '',
  agentName: 'Sales Performance Agent',
  // Power Automate — mode 'url' (flow HTTP URL) | 'server' (Netlify relay + POWER_AUTOMATE_URL)
  paEnabled: ENV.POWER_AUTOMATE_ENABLED === 'true',
  paMode: ENV.POWER_AUTOMATE_ENABLED === 'true' ? 'server' : 'url',
  paUrl: '',
  paAuth: 'none',               // 'none' (anyone with URL) | 'entra' (tenant users — OAuth token)
  // Last test results { dataverse|sharepoint|agent|powerAutomate: { status, sig, msg, at } }
  tests: {}
};
function loadSettings() {
  try { return { ...DEFAULT_SETTINGS, ...(JSON.parse(localStorage.getItem(SETTINGS_KEY)) || {}) }; }
  catch { return { ...DEFAULT_SETTINGS }; }
}
const SETTINGS = loadSettings();
function saveSettings(patch) {
  Object.assign(SETTINGS, patch);
  try { localStorage.setItem(SETTINGS_KEY, JSON.stringify(SETTINGS)); } catch (e) { console.warn('Settings not saved', e); }
}

// ─────────────────────────────────────────────
// 🔧 GENERAL
// ─────────────────────────────────────────────
const CONFIG = {
  appName: ENV.APP_NAME || 'LTM-AI Intelligence Dashboard',
  currency: 'USD', unit: 'M', fiscalYear: 'FY27',
  companyTarget: 47.04, overallLeader: 'Ashutosh',
  fiscalStartMonth: 4, refreshMinutes: 5, storageKey: 'ltm-spd-v1'
};

// ─────────────────────────────────────────────
// 🔐 MICROSOFT ENTRA ID — App: "LTM-AI Intelligence Dashboard"
// Client ID 189bf9db-dd01-4076-9090-603f33c0cc86 · Tenant ff355289-721e-4dd7-a663-afec62ab9d54
// Requires platform "Single-page application" + redirect URIs (see docs/SETUP.md)
// ─────────────────────────────────────────────
const ENTRA = {
  appName: 'LTM-AI Intelligence Dashboard',
  clientId: ENV.ENTRA_CLIENT_ID || '189bf9db-dd01-4076-9090-603f33c0cc86',
  tenantId: ENV.ENTRA_TENANT_ID || 'ff355289-721e-4dd7-a663-afec62ab9d54',
  redirectUri: has(ENV.REDIRECT_URI) ? ENV.REDIRECT_URI : window.location.origin,
  loginScopes: ['User.Read', 'Files.ReadWrite.All', 'Sites.ReadWrite.All'],
  get isConfigured() { return has(this.clientId) && has(this.tenantId); },
  get canRun() { return /^https?:$/.test(location.protocol) && window.isSecureContext; }
};

// ─────────────────────────────────────────────
// 📊 MICROSOFT GRAPH
// ─────────────────────────────────────────────
const GRAPH = { scopes: ['User.Read', 'Files.ReadWrite.All', 'Sites.ReadWrite.All'], baseUrl: 'https://graph.microsoft.com/v1.0' };

// ─────────────────────────────────────────────
// Derived connection info — work on SETTINGS or on a draft (for testing)
// ─────────────────────────────────────────────
function spInfo(s = SETTINGS) {
  let hostname = '', sitePath = '';
  try { const u = new URL(s.sharepointSiteUrl); hostname = u.hostname; sitePath = u.pathname.replace(/\/$/, ''); } catch {}
  const filePath = (s.sharepointFilePath || '').replace(/^\/+/, '');
  return {
    siteUrl: s.sharepointSiteUrl, hostname, sitePath, filePath,
    tableName: s.sharepointTable, worksheet: s.sharepointWorksheet,
    folder: s.sharepointUploadFolder || 'SalesDashboard/Incoming',
    isConfigured: /\.sharepoint\.com$/i.test(hostname) && sitePath.length > 1,
    get hasFile() { return this.isConfigured && has(filePath); }
  };
}
function dvInfo(s = SETTINGS) {
  const url = (s.dataverseUrl || '').trim().replace(/\/+$/, '');
  return {
    url, apiVersion: 'v9.2', scopes: [`${url}/user_impersonation`],
    entitySets: { performance: s.dataverseEntitySet || 'cr_salesperformances', statusRules: 'cr_statusrules', importBatch: 'cr_importbatches', commitments: 'cr_weeklycommitments' },
    isConfigured: /^https:\/\/[\w.-]+\.dynamics\.com$/i.test(url)
  };
}
function agentInfo(s = SETTINGS) {
  const mode = s.agentMode || 'endpoint';
  return {
    enabled: !!s.agentEnabled, mode, name: s.agentName || 'Sales Performance Agent',
    tokenEndpoint: (s.agentTokenEndpoint || '').trim(), serverEndpoint: '/api/agent-token',
    isConfigured: !!s.agentEnabled && (mode === 'server' || /^https:\/\//i.test((s.agentTokenEndpoint || '').trim()))
  };
}
function paInfo(s = SETTINGS) {
  const mode = s.paMode || 'url';
  return {
    enabled: !!s.paEnabled, mode, url: (s.paUrl || '').trim(), auth: s.paAuth || 'none', relayEndpoint: '/api/power-automate',
    // Audience for OAuth-protected HTTP triggers ("Specific users / Any user in my tenant")
    flowScopes: ['https://service.flow.microsoft.com//.default'],
    isConfigured: !!s.paEnabled && (mode === 'server' || /^https:\/\//i.test((s.paUrl || '').trim()))
  };
}

// Live views over the saved settings (same names as the email dashboard)
const SHAREPOINT = new Proxy({}, { get: (_, k) => spInfo()[k] });
const DATAVERSE = new Proxy({}, { get: (_, k) => k === 'columns' ? DV_COLUMNS : dvInfo()[k] });
const AGENT = new Proxy({}, { get: (_, k) => agentInfo()[k] });
const POWER_AUTOMATE = new Proxy({}, { get: (_, k) => paInfo()[k] });
const DV_COLUMNS = { performance: {
  id: 'cr_salesperformanceid', account: 'cr_account', area: 'cr_area', geo: 'cr_geo', accountType: 'cr_accounttype',
  leader: 'cr_leader', fiscalYear: 'cr_fiscalyear', quarter: 'cr_quarter', target: 'cr_target', be: 'cr_bestestimate',
  lost: 'cr_islost', marginTarget: 'cr_margintarget', actualMargin: 'cr_actualmargin' } };

// ─────────────────────────────────────────────
// 🎨 DEFAULT STATUS RULES (editable; first match wins; Gap = Target − BE)
// ─────────────────────────────────────────────
const DEFAULT_STATUS_RULES = [
  { id: 'r-lost',   name: 'Lost',      color: '#111111', onTrack: false, match: 'any', lost: true,  noTarget: false, attMin: null, attMax: null, gapMin: null, gapMax: null },
  { id: 'r-notgt',  name: 'No target', color: '#94a3b8', onTrack: false, match: 'all', lost: false, noTarget: true,  attMin: null, attMax: null, gapMin: null, gapMax: null },
  { id: 'r-ahead',  name: 'Ahead',     color: '#0f9d58', onTrack: true,  match: 'all', lost: false, noTarget: false, attMin: 100,  attMax: null, gapMin: null, gapMax: null },
  { id: 'r-amber',  name: 'At risk',   color: '#f59e0b', onTrack: false, match: 'all', lost: false, noTarget: false, attMin: 85,   attMax: 100,  gapMin: null, gapMax: null },
  { id: 'r-behind', name: 'Behind',    color: '#e5484d', onTrack: false, match: 'all', lost: false, noTarget: false, attMin: null, attMax: 85,   gapMin: null, gapMax: null }
];

window.SPD = { CONFIG, ENTRA, GRAPH, SHAREPOINT, DATAVERSE, AGENT, POWER_AUTOMATE, DEFAULT_STATUS_RULES,
  SETTINGS, DEFAULT_SETTINGS, saveSettings, spInfo, dvInfo, agentInfo, paInfo };
