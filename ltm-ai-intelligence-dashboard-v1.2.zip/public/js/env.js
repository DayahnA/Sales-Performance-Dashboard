/* Public settings (safe to ship to the browser). On Netlify this file is
   regenerated from environment variables by scripts/build-config.js.
   NEVER put secrets here. Users can add/override connections in ⚙️ Data settings. */
window.__ENV__ = {
  APP_NAME: "LTM-AI Intelligence Dashboard",
  ENTRA_CLIENT_ID: "189bf9db-dd01-4076-9090-603f33c0cc86",
  ENTRA_TENANT_ID: "ff355289-721e-4dd7-a663-afec62ab9d54",
  REDIRECT_URI: "",
  DATAVERSE_URL: "",
  SHAREPOINT_SITE_URL: "",
  SHAREPOINT_LIBRARY_FOLDER: "SalesDashboard/Incoming",
  EXCEL_FILE_PATH: "",
  EXCEL_TABLE_NAME: "",
  AGENT_TOKEN_ENDPOINT: "",
  AGENT_ENABLED: "false",
  POWER_AUTOMATE_ENABLED: "false"
};
