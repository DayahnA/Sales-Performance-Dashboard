/* DATA MODEL · CALCULATIONS · STATUS ENGINE · LOCAL PERSISTENCE  (Gap = Target − BE) */
(function () {
  const { CONFIG, DEFAULT_STATUS_RULES } = window.SPD;
  const QUARTERS = ['Q1', 'Q2', 'Q3', 'Q4'];
  const PERIODS = { FY: QUARTERS, H1: ['Q1', 'Q2'], H2: ['Q3', 'Q4'], Q1: ['Q1'], Q2: ['Q2'], Q3: ['Q3'], Q4: ['Q4'], YTD: null };
  function currentFiscalQuarter(date = new Date()) { const off = (date.getMonth() + 1 - CONFIG.fiscalStartMonth + 12) % 12; return QUARTERS[Math.floor(off / 3)]; }
  function quartersFor(p) { if (p === 'YTD') return QUARTERS.slice(0, QUARTERS.indexOf(currentFiscalQuarter()) + 1); return PERIODS[p] || QUARTERS; }

  function demoRecords() {
    const accts = [
      ['Account Alpha', 'Banking', 'Existing', 'Prasad', 'Prasad', [1.5, 1.6, 1.7, 1.8], [1.62, 1.71, 1.66, 1.74]],
      ['Account Bravo', 'Banking', 'Existing', 'Prasad', 'Prasad', [1.3, 1.3, 1.4, 1.5], [1.21, 1.18, 1.25, 1.31]],
      ['Account Charlie', 'Insurance', 'Existing', 'Edwin', 'Edwin', [1.2, 1.3, 1.3, 1.4], [1.25, 1.33, 1.36, 1.42]],
      ['Account Delta', 'Insurance', 'Existing', 'Edwin', 'Prasad', [1.1, 1.2, 1.2, 1.3], [0.98, 1.05, 1.02, 1.08]],
      ['Account Echo', 'Public Sector', 'Existing', 'Thandi', 'Thandi', [1.4, 1.4, 1.5, 1.5], [1.38, 1.36, 1.41, 1.44]],
      ['Account Foxtrot', 'Public Sector', 'Existing', 'Thandi', 'Thandi', [0.9, 1.0, 1.0, 1.1], [0.95, 1.04, 1.06, 1.12]],
      ['Account Golf', 'Manufacturing', 'Existing', 'Edwin', 'Edwin', [1.2, 1.2, 1.3, 1.3], [1.02, 0.99, 1.01, 1.03]],
      ['Account Hotel', 'Retail', 'Existing', 'Prasad', 'Edwin', [1.0, 1.1, 1.1, 1.2], [1.06, 1.12, 1.15, 1.21]],
      ['Account India', 'Telecoms', 'Existing', 'Thandi', 'Thandi', [0.8, 0.8, 0.9, 0.9], [0.30, 0.10, 0.00, 0.00], true],
      ['Net New BFSI', 'Banking', 'Net New BFSI', 'Prasad', 'Prasad', [0.2, 0.3, 0.5, 0.5], [0.00, 0.10, 0.25, 0.40]],
      ['Net New PS', 'Public Sector', 'Net New PS', 'Thandi', 'Thandi', [0.2, 0.3, 0.4, 0.4], [0.00, 0.05, 0.20, 0.30]]
    ];
    const out = [];
    accts.forEach(([account, area, accountType, l1, l2, t, b, lost]) => QUARTERS.forEach((q, i) => out.push({
      account, area, geo: 'South Africa', accountType, leader: i < 2 ? l1 : l2, fiscalYear: CONFIG.fiscalYear, quarter: q,
      target: t[i], be: b[i], lost: !!lost, marginTarget: 0.40, actualMargin: +(0.36 + ((account.length + i) % 5) * 0.02).toFixed(3) })));
    return out;
  }

  function load() { try { return JSON.parse(localStorage.getItem(CONFIG.storageKey)) || {}; } catch { return {}; } }
  function save(patch) { try { localStorage.setItem(CONFIG.storageKey, JSON.stringify({ ...load(), ...patch, savedAt: new Date().toISOString() })); } catch (e) { console.warn('Local save unavailable', e); } }
  function clear() { try { localStorage.removeItem(CONFIG.storageKey); } catch {} }

  const sum = (rows, k) => rows.reduce((a, r) => a + (Number(r[k]) || 0), 0);
  function aggregate(rows) {
    const target = sum(rows, 'target'), be = sum(rows, 'be');
    return { target, be, gap: target - be, attainment: target > 0 ? (be / target) * 100 : null, lost: rows.length > 0 && rows.every(r => r.lost) };
  }
  function groupBy(rows, key) { const m = new Map(); rows.forEach(r => { const k = r[key] ?? '—'; if (!m.has(k)) m.set(k, []); m.get(k).push(r); }); return m; }

  const set = v => v !== null && v !== '' && v !== undefined;
  function ruleMatches(rule, agg) {
    const c = [], att = agg.attainment;
    if (rule.lost) c.push(agg.lost === true);
    if (rule.noTarget) c.push(!(agg.target > 0));
    if (set(rule.attMin)) c.push(att !== null && att >= Number(rule.attMin));
    if (set(rule.attMax)) c.push(att !== null && att < Number(rule.attMax));
    if (set(rule.gapMin)) c.push(agg.gap >= Number(rule.gapMin));
    if (set(rule.gapMax)) c.push(agg.gap < Number(rule.gapMax));
    if (!c.length) return true;
    return rule.match === 'any' ? c.some(Boolean) : c.every(Boolean);
  }
  function statusFor(agg, rules) { for (const r of rules) if (ruleMatches(r, agg)) return r; return { name: 'Unclassified', color: '#64748b', onTrack: false }; }

  const fmtM = v => (v === null || v === undefined || isNaN(v)) ? '—' : `$${Number(v).toFixed(2)}M`;
  const fmtGap = v => (v > 0 ? '+' : v < 0 ? '−' : '') + `$${Math.abs(v).toFixed(2)}M`;
  const fmtPct = v => (v === null || isNaN(v)) ? '—' : `${v.toFixed(1)}%`;

  window.Data = { QUARTERS, PERIODS, quartersFor, currentFiscalQuarter, demoRecords, load, save, clear, aggregate, groupBy, statusFor, ruleMatches,
    defaultRules: () => JSON.parse(JSON.stringify(DEFAULT_STATUS_RULES)), fmtM, fmtGap, fmtPct };
})();
