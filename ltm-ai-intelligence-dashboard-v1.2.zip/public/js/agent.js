/* ================================================================
   🤖 COPILOT STUDIO AGENT — embedded Web Chat
   Connection comes from ⚙️ Data settings → Copilot agent
   (token endpoint or Netlify server). Falls back to a local helper.
   ================================================================ */
(function () {
  let started = false;

  async function start() {
    if (started) return; started = true;
    const host = document.getElementById('agentWebChat');
    const a = window.SPD.agentInfo();
    setSub(a.isConfigured ? `Copilot Studio · ${a.mode === 'server' ? 'secure server' : 'token endpoint'} · sees your filters` : 'Built-in helper · connect your agent in Data settings');
    if (!a.isConfigured) { renderLocalHelper(host); return; }
    if (!window.WebChat) { renderLocalHelper(host, 'The Web Chat library did not load (offline?). Using the built-in helper.'); return; }
    host.innerHTML = '<div class="lh"><div class="lh-log"><div class="lh-msg">⟳ Connecting to your Copilot Studio agent…</div></div></div>';
    try {
      const c = await window.Connectors.getAgentConnection();
      const directLine = window.WebChat.createDirectLine({ token: c.token, domain: c.domain });
      const store = window.WebChat.createStore({}, ({ dispatch }) => next => action => {
        if (action.type === 'DIRECT_LINE/CONNECT_FULFILLED') {
          dispatch({ type: 'WEB_CHAT/SEND_EVENT', payload: { name: 'startConversation', value: { locale: 'en-ZA' } } });
          setTimeout(sendContext, 600);
        }
        return next(action);
      });
      host.innerHTML = '';
      window.WebChat.renderWebChat({ directLine, store, userID: c.userId, username: c.userName, locale: 'en-ZA',
        styleOptions: { accent: '#F1665C', backgroundColor: 'transparent', bubbleBorderRadius: 12, bubbleFromUserBackground: '#0b2545',
          bubbleFromUserTextColor: '#ffffff', bubbleFromUserBorderRadius: 12, primaryFont: "'Plus Jakarta Sans', 'Segoe UI', sans-serif", botAvatarInitials: 'AI', userAvatarInitials: 'ME' } }, host);
      window.Agent._store = store;
    } catch (e) { console.warn('Agent unavailable', e); renderLocalHelper(host, `Agent connection failed (${e.message}). Using the built-in helper.`); }
  }
  function reset() { started = false; window.Agent._store = null; const h = document.getElementById('agentWebChat'); if (h) h.innerHTML = ''; if (document.body.classList.contains('agent-open')) start(); }
  function setSub(t) { const s = document.getElementById('agentSub'); if (s) s.textContent = t; }
  function postEvent(name, value) { window.Agent._store?.dispatch({ type: 'WEB_CHAT/SEND_EVENT', payload: { name, value } }); }
  function postMessage(text) { if (window.Agent._store) window.Agent._store.dispatch({ type: 'WEB_CHAT/SEND_MESSAGE', payload: { text } }); else localAsk(text); }
  function sendContext() { const ctx = window.App?.getContext?.(); if (ctx) postEvent('dashboardContext', ctx); }

  function reviewUpload(p) {
    open();
    if (window.Agent._store) { postEvent('uploadReview', p); postMessage(`Please review my upload "${p.fileName}": ${p.records} records, ${p.errors.length} errors, ${p.warnings.length} warnings. Suggest fixes to the column mapping if needed.`); return; }
    setTimeout(() => {
      localSay(`📥 Upload "${p.fileName}" — ${p.records} records detected (${p.format} layout).`);
      if (p.errors.length) localSay(`❌ ${p.errors.length} error(s):\n• ` + p.errors.slice(0, 5).join('\n• '));
      if (p.warnings.length) localSay(`⚠️ ${p.warnings.length} warning(s):\n• ` + p.warnings.slice(0, 5).join('\n• '));
      const unmapped = Object.entries(p.mapping).filter(([, v]) => v === '—').map(([k]) => k);
      if (unmapped.length) localSay(`Unmapped fields: ${unmapped.join(', ')}. Required: account, quarter, target and BE (or Q1–Q4 columns for wide sheets).`);
      if (!p.errors.length) localSay('✅ This file looks ready to import.');
    }, 50);
  }
  function open() { document.body.classList.add('agent-open'); start(); }
  function close() { document.body.classList.remove('agent-open'); }
  function toggle() { document.body.classList.contains('agent-open') ? close() : open(); }

  function renderLocalHelper(host, note) {
    host.innerHTML = `<div class="lh"><div class="lh-log" id="lhLog"></div>
      <div class="lh-chips"><button data-q="Summarise performance">Summarise</button><button data-q="Which accounts are behind?">Who's behind?</button>
      <button data-q="How do I connect my agent?">Connect agent</button><button data-q="Explain gap">Explain gap</button></div>
      <form class="lh-form" id="lhForm"><input id="lhInput" placeholder="Ask about your sales performance…" autocomplete="off"/><button>Send</button></form></div>`;
    localSay(note || `Hi 👋 I'm the dashboard helper. Connect your Copilot Studio agent in ⚙️ Data settings → Copilot agent for full AI answers.`);
    host.querySelectorAll('.lh-chips button').forEach(b => b.onclick = () => localAsk(b.dataset.q));
    host.querySelector('#lhForm').onsubmit = e => { e.preventDefault(); const i = host.querySelector('#lhInput'); if (i.value.trim()) { localAsk(i.value.trim()); i.value = ''; } };
  }
  function localSay(text, who = 'bot') {
    const log = document.getElementById('lhLog'); if (!log) return;
    const d = document.createElement('div'); d.className = `lh-msg ${who}`; d.textContent = text; log.appendChild(d); log.scrollTop = log.scrollHeight;
  }
  function localAsk(q) {
    localSay(q, 'user');
    const ctx = window.App.getContext(), t = q.toLowerCase();
    if (t.includes('agent') || t.includes('connect')) return localSay('Open ⚙️ Data settings → Copilot agent. Paste the token endpoint from Copilot Studio (Channels → Mobile app), click Test connection, then Save & load. Use "Secure server" if your agent is deployed with a Direct Line secret on Netlify.');
    if (t.includes('upload') || t.includes('source') || t.includes('sharepoint') || t.includes('dataverse'))
      return localSay('Open ⚙️ Data settings to choose Excel upload, Dataverse or SharePoint. Each connection must pass "Test connection" before you can Save & load.');
    if (t.includes('gap')) return localSay('Gap = Target − Best Estimate (BE). Positive = behind plan (red); negative = ahead (green). Leader and team status use total target vs total BE for the selected period.');
    if (t.includes('behind') || t.includes('red') || t.includes('risk')) {
      const b = ctx.offTrack.slice(0, 6);
      return localSay(b.length ? `Off-track for ${ctx.period}:\n• ` + b.map(a => `${a.account} (${a.leader}) — gap ${a.gap}, ${a.status}`).join('\n• ') : 'No accounts are off-track for this view. 🎉');
    }
    localSay(`${ctx.period} ${ctx.fiscalYear} · ${ctx.leader}: Target ${ctx.kpis.target}, BE ${ctx.kpis.be}, gap ${ctx.kpis.gap}, attainment ${ctx.kpis.attainment}. ${ctx.kpis.onTrack} on track, ${ctx.offTrack.length} off track, ${ctx.kpis.lost} lost. Data source: ${ctx.dataSource}.`);
  }
  window.Agent = { start, reset, open, close, toggle, sendContext, reviewUpload, ask: postMessage, _store: null };
})();
