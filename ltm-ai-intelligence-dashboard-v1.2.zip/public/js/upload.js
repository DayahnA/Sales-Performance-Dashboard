/* UPLOAD ENGINE — any Excel/CSV layout: header detection, long/wide, auto-mapping, validation
   Also used for SharePoint workbooks (same parsing for every Excel source). */
(function () {
  const { CONFIG } = window.SPD;
  const SYN = {
    account: ['account', 'customer', 'client', 'account name', 'logo'],
    area: ['area', 'vertical', 'industry', 'segment', 'sector'],
    geo: ['geo', 'region', 'country', 'geography'],
    accountType: ['account type', 'type', 'category', 'nn', 'net new'],
    leader: ['leader', 'sales leader', 'owner', 'account owner', 'a.o', 'ao', 'client partner', 'cp'],
    fiscalYear: ['fiscal year', 'fy', 'year', 'financial year'],
    quarter: ['quarter', 'qtr', 'period'],
    target: ['target', 'budget', 'plan', 'quota'],
    be: ['be', 'best estimate', 'forecast/actual', 'forecast', 'actual', 'achievement', 'forecast / actual'],
    lost: ['lost', 'is lost', 'status'],
    marginTarget: ['margin target', 'target margin'],
    actualMargin: ['actual margin', 'actual margin %', 'margin %', 'margin']
  };
  const FIELDS = Object.keys(SYN), REQUIRED_LONG = ['account', 'quarter', 'target', 'be'];
  const norm = s => String(s ?? '').toLowerCase().replace(/[_\-]+/g, ' ').replace(/\s+/g, ' ').trim();
  const reEsc = s => s.replace(/[.*+?^${}()|[\]\\/]/g, '\\$&');

  function scoreHeader(h, field) {
    const n = norm(h); let best = 0;
    for (const s of SYN[field]) { if (n === s) best = Math.max(best, 3); else if (new RegExp(`(^|\\W)${reEsc(s)}(\\W|$)`).test(n)) best = Math.max(best, 2); }
    return best;
  }
  function readWorkbook(file) {
    return new Promise((resolve, reject) => {
      if (!window.XLSX) return reject(new Error('Excel reader (SheetJS) did not load — check your internet connection.'));
      const fr = new FileReader();
      fr.onload = e => { try { resolve(XLSX.read(new Uint8Array(e.target.result), { type: 'array', cellDates: true })); } catch (err) { reject(new Error(`This file could not be read as a spreadsheet (${err.message}).`)); } };
      fr.onerror = () => reject(new Error('File could not be read.'));
      fr.readAsArrayBuffer(file);
    });
  }
  const sheetToGrid = (wb, s) => XLSX.utils.sheet_to_json(wb.Sheets[s], { header: 1, blankrows: false, defval: '' });

  function detectHeaderRow(grid) {
    let bestIdx = 0, bestScore = -1;
    for (let i = 0; i < Math.min(20, grid.length); i++) {
      const row = (grid[i] || []).map(norm);
      const hasAcct = row.some(c => SYN.account.some(s => c === s || c.includes(s)));
      const valHits = row.filter(c => [...SYN.target, ...SYN.be].some(s => c.includes(s))).length;
      const score = (hasAcct ? 10 : 0) + valHits * 2 + row.filter(Boolean).length * 0.1;
      if (score > bestScore) { bestScore = score; bestIdx = i; }
    }
    return bestIdx;
  }
  function detectWide(headers) {
    const groups = {};
    headers.forEach((h, idx) => {
      const n = norm(h), qm = n.match(/\bq\s?([1-4])\b/); if (!qm) return;
      const q = `Q${qm[1]}`, fym = n.match(/\bfy\s?'?(\d{2,4})\b/);
      const rest = n.replace(/\bq\s?[1-4]\b/, '').replace(/\bfy\s?'?\d{2,4}\b/, '').trim();
      for (const f of ['target', 'be', 'leader', 'marginTarget', 'actualMargin']) {
        if (scoreHeader(rest, f) >= 2 || (f === 'be' && /forecast|actual|\bbe\b/.test(rest) && !/margin/.test(rest))) {
          if ((f === 'target' || f === 'be') && /margin/.test(rest)) continue;
          groups[q] = groups[q] || { quarter: q, fy: fym ? `FY${fym[1].slice(-2)}` : null };
          if (groups[q][f] === undefined) groups[q][f] = idx;
          break;
        }
      }
    });
    const qs = Object.values(groups).filter(g => g.target !== undefined || g.be !== undefined);
    return qs.length ? qs.sort((a, b) => a.quarter.localeCompare(b.quarter)) : null;
  }
  function autoMap(headers) {
    const map = {};
    FIELDS.forEach(f => { let best = -1, bs = 0; headers.forEach((h, i) => { const s = scoreHeader(h, f); if (s > bs) { bs = s; best = i; } }); map[f] = bs > 0 ? best : -1; });
    if (map.be === map.target) map.be = -1;
    if (map.lost === map.accountType) map.lost = -1;
    return map;
  }
  function toNum(v) {
    if (v === '' || v === null || v === undefined) return 0;
    if (typeof v === 'number') return v;
    const s = String(v).replace(/[$R,\s]/g, '').replace(/%$/, ''), n = Number(s.replace(/[()]/g, ''));
    return isNaN(n) ? NaN : (/^\(.*\)$/.test(s) ? -n : n);
  }
  const toQuarter = v => { const m = String(v).toUpperCase().match(/Q\s?([1-4])/); return m ? `Q${m[1]}` : null; };
  const toLost = v => v === true || ['yes', 'y', 'true', '1', 'lost', 'closed lost'].includes(norm(v));

  function analyse(grid) {
    const headerRow = detectHeaderRow(grid);
    const headers = (grid[headerRow] || []).map((h, i) => String(h || `Column ${i + 1}`).trim());
    const rows = grid.slice(headerRow + 1).filter(r => r.some(c => c !== '' && c !== null));
    const map = autoMap(headers), wideGroups = detectWide(headers);
    const format = (map.quarter >= 0 && map.target >= 0) ? 'long' : (wideGroups ? 'wide' : 'long');
    return { headerRow, headers, rows, format, map, wideGroups };
  }

  function buildRecords(a, opts) {
    const { format, map, wideGroups } = opts, div = Number(opts.unitDivisor) || 1, fyDefault = opts.defaultFY || CONFIG.fiscalYear;
    const errors = [], warnings = [], records = [], cell = (r, i) => (i >= 0 ? r[i] : '');
    a.rows.forEach((r, ri) => {
      const line = a.headerRow + ri + 2, account = String(cell(r, map.account) || '').trim();
      if (!account) { warnings.push(`Row ${line}: no account name — skipped.`); return; }
      if (/^(total|grand total|sum)$/i.test(account)) { warnings.push(`Row ${line}: total row skipped.`); return; }
      const base = { account, area: String(cell(r, map.area) || '').trim() || 'Unassigned', geo: String(cell(r, map.geo) || '').trim() || 'South Africa',
        accountType: String(cell(r, map.accountType) || '').trim() || (/net new|^nn/i.test(account) ? 'Net New' : 'Existing'),
        lost: map.lost >= 0 ? toLost(cell(r, map.lost)) : false };
      const push = (q, fy, tRaw, bRaw, leader, mt, am) => {
        const t = toNum(tRaw), b = toNum(bRaw);
        if (isNaN(t) || isNaN(b)) { errors.push(`Row ${line} ${q}: non-numeric target/BE ("${tRaw}", "${bRaw}").`); return; }
        if (t < 0) warnings.push(`Row ${line} ${q}: negative target.`);
        records.push({ ...base, quarter: q, fiscalYear: fy || fyDefault, leader: String(leader || '').trim() || 'Unassigned', target: t / div, be: b / div,
          marginTarget: mt === '' || mt === undefined ? null : toNum(mt), actualMargin: am === '' || am === undefined ? null : toNum(am) });
      };
      if (format === 'wide') (wideGroups || []).forEach(g => push(g.quarter, g.fy, cell(r, g.target ?? -1), cell(r, g.be ?? -1),
        g.leader !== undefined ? cell(r, g.leader) : cell(r, map.leader), cell(r, g.marginTarget ?? -1), cell(r, g.actualMargin ?? -1)));
      else {
        const q = toQuarter(cell(r, map.quarter));
        if (!q) { errors.push(`Row ${line}: quarter "${cell(r, map.quarter)}" not recognised (use Q1–Q4).`); return; }
        const fym = String(cell(r, map.fiscalYear) || '').match(/(\d{2,4})/);
        push(q, fym ? `FY${fym[1].slice(-2)}` : null, cell(r, map.target), cell(r, map.be), cell(r, map.leader), cell(r, map.marginTarget), cell(r, map.actualMargin));
      }
    });
    if (format === 'long') REQUIRED_LONG.forEach(f => { if (map[f] < 0) errors.unshift(`Required column not mapped: ${f}.`); });
    if (format === 'wide' && map.account < 0) errors.unshift('Required column not mapped: account.');
    const seen = new Set();
    records.forEach(r => { const k = `${r.fiscalYear}|${r.account}|${r.quarter}`; if (seen.has(k)) warnings.push(`Duplicate ${r.account} ${r.quarter} ${r.fiscalYear} — values will be summed.`); seen.add(k); });
    const maxT = Math.max(0, ...records.map(r => r.target));
    if (maxT > 1000) warnings.push(`Largest target is ${maxT.toLocaleString()} — if these are raw dollars, set "Divide values by" to 1,000,000.`);
    return { records, errors, warnings };
  }

  function gridToRecords(grid) {
    const a = analyse(grid);
    const maxVal = Math.max(0, ...a.rows.flat().filter(v => typeof v === 'number'));
    const div = maxVal > 100000 ? 1e6 : maxVal > 1000 ? 1e3 : 1;
    return buildRecords(a, { format: a.format, map: a.map, wideGroups: a.wideGroups || [], unitDivisor: div });
  }

  window.Upload = { FIELDS, SYN, readWorkbook, sheetToGrid, analyse, buildRecords, autoMap, gridToRecords };
})();
