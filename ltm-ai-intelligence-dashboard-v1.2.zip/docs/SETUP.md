# Setup guide

## 1. Entra ID — "LTM-AI Intelligence Dashboard"
The client ID and tenant ID are already in the code. In **portal.azure.com → Entra ID → App registrations → LTM-AI Intelligence Dashboard**:
1. **Authentication → Add a platform → Single-page application.** Add these redirect URIs: `https://<site>.netlify.app` and `http://localhost:8888`.
2. **API permissions (Delegated)** → **Grant admin consent**:
   | API | Permission | Used by |
   |---|---|---|
   | Microsoft Graph | User.Read | Sign-in, server checks |
   | Microsoft Graph | Files.ReadWrite.All, Sites.ReadWrite.All | SharePoint |
   | Dynamics CRM | user_impersonation | Dataverse |
   | Power Automate (Microsoft Flow Service) | User | Only for tenant-only flow triggers |
3. **Client secret:** the browser app doesn't use one. A secret was shared in chat, so **create a new one and delete the old one** under Certificates & secrets. Store the new secret only as the Netlify variable `ENTRA_CLIENT_SECRET`.

## 2. Adding connections (in the app)
Open **⚙️ Data settings**. For each tab: fill in the fields, click **🔌 Test connection**, fix anything shown in red, then click **Save & load data**. Use **Test all** to run every needed test at once.

### Dataverse
- Environment URL: Power Platform admin center → Environments → the environment → **Environment URL**.
- Table: the entity set name, e.g. `cr_salesperformances` (see DATAVERSE_SCHEMA.md).
- The test calls `WhoAmI()`, reads 1 row, counts the rows, checks the columns `cr_account`, `cr_quarter`, `cr_target` and `cr_bestestimate`, and looks for the optional tables.

### SharePoint
- Site URL, e.g. `https://ltimindtree.sharepoint.com/sites/LTMSalesSA`.
- Excel file: type the path inside *Documents*, or use **Browse files**. Picking a file runs the test automatically.
- The test finds the site, reads the workbook through the same engine as uploads, and checks the archive folder.

### Copilot Studio agent
| Method | When to use it | Setup |
|---|---|---|
| **Token endpoint** (default) | The agent's authentication is *No authentication* or *Authenticate manually* | Copilot Studio → agent → **Channels → Mobile app** → copy the **Token Endpoint** and paste it in |
| **Secure server (Netlify)** | You want the Direct Line secret kept on the server | Settings → Security → Web channel security → copy Secret 1 → Netlify variable `DIRECTLINE_SECRET` (and `DIRECTLINE_DOMAIN` for regional environments) |

The test gets a token, detects the region (`regionalchannelsettings`) and opens a real Direct Line conversation.

### Power Automate
| Method | Setup |
|---|---|
| **Flow URL**, *Anyone* | Paste the HTTP POST URL. It's saved only in that user's browser |
| **Flow URL**, *tenant users (Entra ID)* | Set the trigger's "Who can trigger the flow" to *Any user in my tenant*, and grant the app the Power Automate *User* permission |
| **Secure server relay** | Netlify variable `POWER_AUTOMATE_URL`. The browser never sees the URL |

The flow must answer the `test` action with 200/202 (see POWER_AUTOMATE.md). If the test reports *blocked request (CORS)*, switch to the secure server relay.

## 3. Rules the dashboard enforces
- **Required connections:** the chosen data source, SharePoint (if archiving is on), the agent (if on) and Power Automate (if on).
- **Save & load** is disabled until all required connections show ✓. The footer lists what's missing.
- **Re-testing:** a test result only counts while its fields are unchanged. Editing a field means testing that connection again.
- **Status at a glance:** the four dots in the top bar show each connection's saved status. Click them to open Data settings.

## 4. Netlify
Add the variables from `.env.example`, deploy, then open `/api/health`. It shows which secrets are set (true/false only).

## Troubleshooting
| Message | Fix |
|---|---|
| Sign-in only works from Netlify or localhost | You opened the HTML as a local file |
| AADSTS50011 / AADSTS9002326 | Add the site as an **SPA** redirect URI |
| Could not get a token … consent | Grant admin consent for that API |
| Dataverse 403 | The user needs a security role on the table |
| SharePoint 404 | Check the site URL or file path |
| Token endpoint returned 404 | Publish the agent and re-copy the endpoint |
| Direct Line refused the conversation | Region mismatch or the agent isn't published |
| Flow returned 401/403 | Set "Who can trigger" to match the Authentication option |
| Browser blocked the request (CORS) | Use the secure server mode |
