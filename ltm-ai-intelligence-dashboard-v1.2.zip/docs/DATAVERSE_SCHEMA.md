# Dataverse schema (publisher prefix `cr_`)

## Sales Performance — entity set `cr_salesperformances` (required)
One row per **account × fiscal year × quarter**.
| Display name | Logical name | Type |
|---|---|---|
| Account (primary) | cr_account | Text (200) |
| Area | cr_area | Text (100) |
| Geo | cr_geo | Text (100) |
| Account Type | cr_accounttype | Text (50) |
| Sales Leader | cr_leader | Text (100) |
| Fiscal Year | cr_fiscalyear | Text (10) |
| Quarter | cr_quarter | Text (2), Q1–Q4 |
| Target ($M) | cr_target | Decimal (4 dp) |
| Best Estimate ($M) | cr_bestestimate | Decimal (4 dp) |
| Is Lost | cr_islost | Yes/No |
| Margin Target | cr_margintarget | Decimal |
| Actual Margin | cr_actualmargin | Decimal |

The connection test checks that `cr_account`, `cr_quarter`, `cr_target` and `cr_bestestimate` exist.

## Optional tables (the test shows a warning if they're missing)
- **Status Rule** `cr_statusrules`: cr_name, cr_rulesjson (Multiline 100,000)
- **Weekly Commitment** `cr_weeklycommitments`: cr_name, cr_leader, cr_amount, cr_weekending, cr_note
- **Import Batch** `cr_importbatches`: cr_name, cr_rowcount, cr_importedby

For a different prefix, change the table in Data settings and the column names in `DV_COLUMNS` in `public/js/config.js`.
