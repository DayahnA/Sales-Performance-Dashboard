# Power Automate flow

1. **Instant cloud flow → "When an HTTP request is received".** Set *Who can trigger the flow* to match the option you'll choose in Data settings.
2. Request body schema:
```json
{ "type": "object", "properties": {
  "action": {"type":"string"}, "account": {"type":"string"}, "leader": {"type":"string"}, "to": {"type":"string"},
  "subject": {"type":"string"}, "body": {"type":"string"}, "target": {"type":"string"}, "be": {"type":"string"},
  "gap": {"type":"string"}, "status": {"type":"string"}, "period": {"type":"string"}, "timestamp": {"type":"string"},
  "user": {"type":"string"}, "userName": {"type":"string"}, "triggeredBy": {"type":"string"} } }
```
3. Add a **Switch** on `triggerBody()?['action']`:
   | Case | Actions |
   |---|---|
   | **test** | **Response 200** with `{"ok":true}`. Does nothing else. Used by *Test connection* |
   | notify | Find the leader → Send an email (V2) → optional Teams post |
   | request_commitment | Teams adaptive card → Dataverse "Add a new row" |
   | escalate | Email the overall leader |
   | import_completed | Teams post to the sales channel |
4. Add a **Response 202** after the Switch for the other actions.
5. Copy the HTTP POST URL. Paste it in **Data settings → Power Automate**, or store it as the Netlify variable `POWER_AUTOMATE_URL` for the relay.
