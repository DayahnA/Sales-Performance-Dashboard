# Copilot Studio agent

## Connect (Data settings → Copilot agent)
- **Token endpoint:** set the agent's authentication to *No authentication* or *Authenticate manually*, publish it, then go to **Channels → Mobile app** and copy the **Token Endpoint**. Paste it in, test, then save.
- **Secure server:** go to **Settings → Security → Web channel security** and copy Secret 1 into the Netlify variable `DIRECTLINE_SECRET`. For a regional environment, also set `DIRECTLINE_DOMAIN` (e.g. `https://europe.directline.botframework.com/v3/directline`). Redeploy, choose *Secure server*, then test.

The test opens a real Direct Line conversation, so a ✓ means the agent can be reached.

## Events the dashboard sends
| Event | `value` |
|---|---|
| startConversation | { locale } |
| dashboardContext | FY, period, leader, KPIs, off-track accounts, status rules, data source |
| uploadReview | file, sheet, layout, headers, sample rows, mapping, errors, warnings |

Create one topic per event (Trigger: *Event received*). Each topic should set `Global.DashboardContext` or `Global.UploadReview` to `System.Activity.Value`.

## Instructions
```
ROLE: You are the LTM Sales Performance Agent inside the LTM-AI Intelligence Dashboard.
CONTEXT: Use Global.DashboardContext. State the period, FY, leader and data source you describe.
DEFINITIONS: H1=Q1+Q2, H2=Q3+Q4, YTD=Q1..current fiscal quarter (FY starts April). Gap = Target − BE (positive = behind). Black = Lost. $47.04M company target is separate from the sum of account targets.
UPLOAD HELP: With Global.UploadReview, explain errors simply, suggest the column mapping, flag unit issues. Never invent figures.
DATA ACTIONS: Write to Dataverse only when explicitly asked, and confirm the values first.
STYLE: Executive and concise. Lead with the answer, then up to 3 actions. Use $M with 2 decimals.
```
