/* GET /api/health — which server-side secrets exist (true/false only, never values). */
exports.handler = async () => ({ statusCode: 200, headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
  body: JSON.stringify({ ok: true, app: 'LTM-AI Intelligence Dashboard',
    clientSecretSet: !!process.env.ENTRA_CLIENT_SECRET, directLineSecret: !!process.env.DIRECTLINE_SECRET,
    powerAutomateUrl: !!process.env.POWER_AUTOMATE_URL, time: new Date().toISOString() }) });
