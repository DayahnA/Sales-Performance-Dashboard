/* POST /api/agent-token — "Secure server" agent mode.
   Exchanges the Copilot Studio Direct Line SECRET (env DIRECTLINE_SECRET)
   for a short-lived token bound to the signed-in user. Also returns the
   Direct Line domain so the browser can test and connect. */
const { requireEntraUser, json } = require('./_shared/auth');
exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return json(405, { error: 'Method not allowed' });
  try {
    const secret = process.env.DIRECTLINE_SECRET;
    if (!secret) return json(503, { error: 'DIRECTLINE_SECRET is not set on Netlify — add it, redeploy, or use the Token endpoint method' });
    const user = await requireEntraUser(event);
    const domain = (process.env.DIRECTLINE_DOMAIN || 'https://directline.botframework.com/v3/directline').replace(/\/$/, '');
    const userId = `dl_${user.id}`;
    const res = await fetch(`${domain}/tokens/generate`, { method: 'POST',
      headers: { Authorization: `Bearer ${secret}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ user: { id: userId, name: user.name } }) });
    if (!res.ok) return json(502, { error: `Direct Line rejected the secret (${res.status}) — check DIRECTLINE_SECRET / DIRECTLINE_DOMAIN` });
    const d = await res.json();
    return json(200, { token: d.token, domain, conversationId: d.conversationId, expiresIn: d.expires_in, userId, userName: user.name });
  } catch (e) { return json(e.status || 500, { error: e.message }); }
};
