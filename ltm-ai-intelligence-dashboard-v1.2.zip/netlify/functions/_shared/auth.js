/* Validates the caller's Microsoft Entra ID token (tenant ff355289-…) by
   checking the tenant claim and calling Microsoft Graph /me. */
const TENANT = process.env.ENTRA_TENANT_ID || 'ff355289-721e-4dd7-a663-afec62ab9d54';
async function requireEntraUser(event) {
  const header = event.headers.authorization || event.headers.Authorization || '';
  const token = header.replace(/^Bearer\s+/i, '').trim();
  if (process.env.ALLOW_ANONYMOUS === 'true' && !token) return { id: 'anonymous', name: 'Guest', anonymous: true };
  if (!token) { const e = new Error('Sign in with Microsoft first (the server needs your Entra token)'); e.status = 401; throw e; }
  try {
    const payload = JSON.parse(Buffer.from(token.split('.')[1], 'base64url').toString('utf8'));
    if (payload.tid && payload.tid !== TENANT) { const e = new Error('Your account is not in the LTM tenant'); e.status = 403; throw e; }
  } catch (err) { if (err.status) throw err; }
  const res = await fetch('https://graph.microsoft.com/v1.0/me?$select=id,displayName,userPrincipalName', { headers: { Authorization: `Bearer ${token}` } });
  if (!res.ok) { const e = new Error('Invalid or expired sign-in token'); e.status = 401; throw e; }
  const me = await res.json();
  return { id: me.id, name: me.displayName, upn: me.userPrincipalName };
}
const json = (status, body) => ({ statusCode: status, headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' }, body: JSON.stringify(body) });
module.exports = { requireEntraUser, json };
