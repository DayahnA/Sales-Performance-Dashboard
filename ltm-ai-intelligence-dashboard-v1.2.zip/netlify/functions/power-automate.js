/* POST /api/power-automate — "Secure server relay" mode.
   Forwards dashboard actions to the flow URL in env POWER_AUTOMATE_URL
   after checking the caller's Entra sign-in. The "test" action is used by
   Data settings → Power Automate → Test connection. */
const { requireEntraUser, json } = require('./_shared/auth');
const ALLOWED = new Set(['test', 'notify', 'request_commitment', 'escalate', 'import_completed']);
exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return json(405, { error: 'Method not allowed' });
  try {
    const url = process.env.POWER_AUTOMATE_URL;
    if (!url) return json(503, { error: 'POWER_AUTOMATE_URL is not set on Netlify — add it, redeploy, or use the Flow URL method' });
    const user = await requireEntraUser(event);
    let body; try { body = JSON.parse(event.body || '{}'); } catch { return json(400, { error: 'Invalid JSON' }); }
    if (!ALLOWED.has(body.action)) return json(400, { error: `Unsupported action "${body.action}"` });
    const payload = { ...body, user: user.upn || user.id, userName: user.name, relayedAt: new Date().toISOString() };
    const res = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
    if (!(res.ok || res.status === 202)) return json(502, { error: `The flow returned ${res.status}` });
    return json(202, { ok: true });
  } catch (e) { return json(e.status || 500, { error: e.message }); }
};
