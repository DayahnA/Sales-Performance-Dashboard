# LTM-AI Intelligence Dashboard — Sales Performance

An executive sales-performance dashboard. It's hosted on **Netlify** and uses **Microsoft Entra ID** for sign-in. Users add and **test** every connection in **⚙️ Data settings**:

| Tab | What the user adds | What "Test connection" does |
|---|---|---|
| Data source | Excel upload, Dataverse or SharePoint | Shows which connections the chosen source needs |
| Dataverse | Environment URL and table | Calls WhoAmI, reads the table and checks the columns |
| SharePoint | Site, Excel file (or **Browse files**), table or sheet, archive folder | Finds the site, reads the sales rows and checks the folder |
| Copilot agent | Token endpoint **or** secure Netlify server | Gets a token and opens a real Direct Line conversation |
| Power Automate | Flow URL (anyone, or tenant-only with Entra) **or** secure Netlify relay | Sends `{"action":"test"}` and expects 200/202 |

**Save & load data stays locked until every connection in use has passed its test.** If you change a field after testing, that connection has to be tested again.

| Entra app registration | Value |
|---|---|
| Name | LTM-AI Intelligence Dashboard |
| Client ID | `189bf9db-dd01-4076-9090-603f33c0cc86` |
| Tenant ID | `ff355289-721e-4dd7-a663-afec62ab9d54` |
| Client secret | Not used in the browser. Store it only as the Netlify variable `ENTRA_CLIENT_SECRET` |

## Run it
```bash
npm install
npm run start          # http://localhost:8888 (sign-in works on localhost)
npx netlify dev        # also runs the /api functions (secure server modes)
```

## Deploy
Push to GitHub → Netlify → Import. Add the variables from `.env.example`. In Entra, add `https://<site>.netlify.app` as a **Single-page application** redirect URI.

See `docs/SETUP.md` for full steps.
